/**
 * МАДЖОНГ · мультиплеер-сервер v2 (Deno Deploy: WebSocket + KV/SQL).
 *
 * ЗАЧЕМ v2: прошлая версия хранила комнаты только в KV и падала
 * в двух местах: (1) приветствие с устаревшими кредами получало
 * push err ROOM_NOT_FOUND и клиент показывал «игра больше не
 * существует» ещё до всякой игры; (2) свежесозданная комната
 * иногда была невидима из другого изолята (репликация KV) —
 * вход по коду падал с «не найдено». Теперь: join с ретраями,
 * hello БЕЗ страшных ошибок, счёт серии побед (wins), гигиена
 * очереди матчмейкинга.
 *
 * ХРАНИЛИЩЕ (Task 39→42): Deno KV на старом Deno Deploy был
 * отключён (сентябрь 2025); В НОВОЙ консоли Deno Deploy KV снова
 * доступен как managed-база (Databases → Provision Database → Deno KV,
 * затем Deno.openKv() коннектится сам) — это ЛУЧШИЙ путь. Запасной —
 * SQL-хранилище (Postgres через DATABASE_URL, напр. filess/Neon):
 * ВСЕ изоляты видят одно состояние, друзья/чаты/комнаты переживают
 * любые рестарты. Интерфейс тот же Kv (get/set/delete/list/atomic-CAS/
 * watch), watch для SQL — поллинг 1.2 c (пуши вьюх оппоненту ≤ 1.2 c).
 * Фолбэки: MJ_KV=memory (тесты), локальный Deno.openKv() (dev-файл).
 *
 * СТАРТ (Task 42): подключение хранилища НЕ блокирует запуск. Раньше
 * топ-левел await с ретраями (до 55 c) держал Deno.serve — деплой в
 * Playground не укладывался в окно Warm up (~5 c) и падал целиком
 * (Warm up/Route/Register crons Failed, «Not yet deployed»). Теперь
 * сервер слушает мгновенно, начиная с MemoryKv; постоянное хранилище
 * поднимается фоном (ретраи с бэкоффом), при успехе содержимое памяти
 * переносится в него и биндинг меняется на лету.
 *
 * АРХИТЕКТУРА (несколько изолятов Deno Deploy):
 *  - состояние комнат и тикетов — ТОЛЬКО в KV (ключи ['room',code],
 *    ['mm',id]); изменение — через atomic CAS (конфликты ретраим);
 *  - каждый изолят держит свои сокеты и для каждой комнаты с
 *    локальным сокетом подписан kv.watch → мгновенный кросс-изолятный
 *    push вьюхи сопернику (и событие «соперник собрал пару»);
 *  - лобби открытых игр — лёгкий поллинг KV (2 c) только если
 *    есть подписчики;
 *  - «сердцебиение» игрока = любые сообщения (view/event) пишут
 *    lastSeen в комнату; свипер изолята раз в 1.5 c досматривает
 *    авт-исходы (тайм-аут, дисконнект 30 c) и чистит мёртвое;
 *  - janitor (раз в ~5 мин) удаляет протухшие комнаты из KV.
 *
 * ПРОТОКОЛ (JSON поверх WS; rid — идемпотентность запрос-ответ):
 *  ← {t:'hello', uid, name, code?, playerId?}   представиться/вернуться
 *  → {t:'hello', ok}  (+ {t:'room'} если комната жива; если мертва —
 *     НИКАКИХ ошибок: клиент сам спросит view и молча почистит креды)
 *  ← {t:'lobby', on}                подписка на список открытых игр
 *  → {t:'lobby', rooms:[...]}       (каждые ~2 c и сразу по подписке)
 *  ← {t:'create', name, level, visibility}   создать игру
 *  → {t:'room', view, playerId}
 *  ← {t:'join', code, name}        вход по коду (с ретраями свежей комнаты)
 *  → {t:'room', view, playerId} | {t:'err', code}
 *  ← {t:'view', score?, pairsDone?}           прогресс + присутствие
 *  → {t:'room', view}
 *  ← {t:'event', kind:'match', tile1Id, tile2Id, score, pairsDone}
 *  → {t:'event', kind:'match', playerId, ...} сопернику (мгновенно)
 *  ← {t:'finish', reason:'cleared'|'tray', score, pairsDone}
 *  → {t:'room', view}                        (итог + счёт серии wins)
 *  ← {t:'advance', kind:'rematch'|'next'}    реванш/след. уровень (оба!)
 *  → {t:'room', view} | {t:'err', code:'ROOM_EMPTY'}
 *  ← {t:'leave'}                             выйти (сопернику — победа)
 *  ← {t:'match', name, level}                быстрый матч: в очередь
 *  → {t:'mm', status:'search'} | {t:'room', view, playerId}
 *  ← {t:'match-heart'} / {t:'match-leave'}   держать/убрать тикет
 *  ← {t:'ping'} → {t:'pong'}                 живость соединения
 *  сервер шлёт {t:'hb'} каждые 3 c; клиент отвечает {t:'ping'} —
 *  это и есть присутствие игрока (lastSeen обновляется и в свёрнутой
 *  вкладке, где таймеры страницы душатся до ~1/мин)
 *
 * ДРУЗЬЯ (Task 37, KV): постоянный uid игрока — из hello. Возможности:
 *  ← {t:'f_sync'}                     полное состояние (и после hello)
 *  → {t:'friends', state}
 *  ← {t:'f_add', to | code}            отправить заявку в друзья
 *  ← {t:'f_accept', from}              принять (встречные заявки — сразу оба)
 *  ← {t:'f_decline', from}             отклонить
 *  ← {t:'f_remove', uid}               удалить из друзей
 *  ← {t:'f_msg', to, text}             сообщение другу (≤ 300 симв.)
 *  ← {t:'f_read', with}                прочитать переписку
 *  ← {t:'f_chat_load', with} → {t:'f_chat', with, msgs}
 *  ← {t:'f_invite', to, level}         позвать в битву (создаём комнату)
 *  → {t:'room', view, playerId}        (я — хост, жду ответа друга)
 *  ← {t:'f_invite_reply', from, accept} ответ друга на приглашение
 *  → {t:'f_event', kind:'req'|'accept'|'msg'|'invite'|...} события
 *  → {t:'friends', state}              обновление состояния обеим сторонам
 *
 * СЧЁТ СЕРИИ (wins): у каждого игрока в комнате есть счётчик побед;
 * растёт при любом исходе в его пользу (cleared/tray/timeout/
 * disconnect/left), НЕ сбрасывается при реванше и «дальше» —
 * серия живёт, пока в комнате одни и те же два игрока.
 *
 * ЗАПУСК: локально  deno run --unstable-kv --allow-net --allow-env main.ts
 *          на Deploy без флагов. MJ_KV=memory — аварийный режим без
 *          KV (один изолят, только для отладки).
 */

/* ============================== КОНСТАНТЫ ============================== */

const ISOLATE = crypto.randomUUID().slice(0, 8);
const PORT = Number(Deno.env.get('PORT') ?? 8080);

/** запас на интро-карточку и отсчёт 3-2-1 у обоих игроков */
const INTRO_BUDGET_MS = 8000;
/** «в сети»: игрок давал о себе знать не позже этого
 *  (12 c — как в рабочем образце: полл 4 c + мобильный джиттер
 *  не должен мерцать флагом «потерял связь» каждые пару секунд) */
const PRESENCE_MS = 12000;
/** так долго нет вестей → победа соперника по отключению
 *  (30 c: перезагрузка страницы НЕ должна рвать матч ложно) */
const ONLINE_GRACE_MS = 30000;
/** время на пару — как в матче против бота */
const TIME_PER_PAIR_MS = 4500;
const TIME_MIN_MS = 90_000;
const TIME_MAX_MS = 270_000;
/** комнаты живут 6 часов, «ожидание друга» — час */
const ROOM_TTL_MS = 6 * 60 * 60 * 1000;
const WAITING_TTL_MS = 60 * 60 * 1000;
/** создатель ждущей комнаты пропал — убираем игру из лобби */
const WAITING_HOST_STALE_MS = 45_000;
/** максимум записей в списке открытых игр */
const OPEN_LIST_MAX = 30;
/** тикет матчмейкинга без признаков жизни столько — выпадает */
const TICKET_TTL_MS = 15_000;
/** окно «свежести» для СПАРИВАНИЯ тикетов (Task 45). Сердце
 *  живого клиента в очереди приходит каждые ~4 c — тикет старше
 *  8 c означает, что его сокет мёртв (изолят убит/обрыв без
 *  close). Раньше такой тикет-призрак жил до 15 c и мог попасть
 *  в пару: живому игроку мгновенно «соперник отключился» —
 *  один из источников «вылетает во время игры по сети». Призраки
 *  в спаривание не идут; дотянувшие до TTL — удаляются. */
const TICKET_PAIR_FRESH_MS = 8_000;
/** сколько watch комнаты живёт БЕЗ единого локального сокета
 *  (Task 45). Раньше watch брошенной комнаты (оба ушли без leave)
 *  поллил SQL ДО TTL комнаты (6 часов!) — watch'и накапливались,
 *  пул соединений забивался, живые запросы падали в таймауты →
 *  «вылетает во время игры по сети».
 *  12 c > реконнект-бэкоффа клиента — переподключение успевает;
 *  финиш «дисконнект» для совсем брошенных комнат досмотрит
 *  janitor (выметать их некому — вьюхи бросившим не нужны) */
const WATCH_EMPTY_GRACE_MS = 12_000;
/** ретраи чтения свежей комнаты (репликация KV между изолятами) */
const FRESH_ROOM_RETRIES = 4;
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // без I O 0 1
const CODE_LEN = 5;

/* ---- друзья (Task 37) ---- */
/** друзей максимум */
const FRIENDS_MAX = 50;
/** заявок максимум (входящих и исходящих) */
const FRIEND_REQS_MAX = 20;
/** сообщений в истории чата пары */
const CHAT_MSGS_MAX = 100;
/** максимальная длина сообщения */
const CHAT_TEXT_MAX = 300;
/** приглашение в битву живёт 60 c */
const INVITE_TTL_MS = 60_000;
/** «онлайн»: uid подавал признаки жизни не позже этого */
const FRIEND_ONLINE_MS = 30_000;
/** как часто писать маркер присутствия в KV (с каждого сокета) */
const ONLINE_TOUCH_MS = 12_000;
/** короткий код для добавления в друзья */
const FC_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const FC_LEN = 6;

/** пары по уровню (цикл 10 уровней — 10 схем, см. layouts.ts) */
const PAIRS_BY_LEVEL = [14, 20, 22, 32, 36, 18, 21, 26, 32, 40];

/* =============================== ТИПЫ =============================== */

type RoomFinishReason =
  | 'cleared'
  | 'tray'
  | 'timeout'
  | 'disconnect'
  | 'left';

interface PlayerState {
  id: string;
  name: string;
  hue: number;
  score: number;
  pairsDone: number;
  lastSeen: number;
  finished: 'cleared' | 'tray' | null;
  /** счёт серии побед с этим соперником */
  wins: number;
  /** постоянный uid игрока (Task 37: «Добавить в друзья» из матча) */
  uid?: string;
}

interface RoomEventInfo {
  playerId: string;
  tile1Id: number;
  tile2Id: number;
  score: number;
  pairsDone: number;
  at: number;
}

interface RoomState {
  code: string;
  level: number;
  seed: number;
  status: 'waiting' | 'playing' | 'result';
  hostId: string;
  visibility: 'open' | 'closed';
  startedAt: number;
  timeTotalMs: number;
  createdAt: number;
  players: PlayerState[];
  result: { winnerId: string; reason: RoomFinishReason } | null;
  /** playerId → 'rematch' | 'next' (согласия на продолжение) */
  advanceBy: Record<string, 'rematch' | 'next'>;
  /** последнее событие «собрал пару» — доехать до соперника */
  lastEvent: RoomEventInfo | null;
}

interface TicketState {
  id: string;
  name: string;
  hue: number;
  level: number;
  createdAt: number;
  lastSeen: number;
  /** постоянный uid владельца тикета (Task 37) */
  uid?: string;
  /** подобрали: комната готова */
  paired: {
    code: string;
    playerId: string;
  } | null;
}

/** публичное состояние комнаты — то, что видит клиент */
interface RoomView {
  code: string;
  status: 'waiting' | 'playing' | 'result';
  level: number;
  seed: number;
  hostId: string;
  timeTotalMs: number;
  startedAt: number;
  serverNow: number;
  players: {
    id: string;
    name: string;
    hue: number;
    score: number;
    pairsDone: number;
    online: boolean;
    finished: 'cleared' | 'tray' | null;
    wins: number;
    /** постоянный uid игрока (для «Добавить в друзья», Task 37) */
    uid?: string;
  }[];
  result: { winnerId: string; reason: RoomFinishReason } | null;
  visibility: 'open' | 'closed';
  advanceOffers: { playerId: string; kind: 'rematch' | 'next' }[];
}

interface OpenRoomInfo {
  code: string;
  level: number;
  hostName: string;
  hue: number;
  createdAt: number;
  players: number;
}

/* ====================== KV-АБСТРАКЦИЯ (с фолбэком) ====================== */

type KvKey = unknown[];
interface KvEntry<T> {
  key: KvKey;
  value: T | null;
  versionstamp: string;
}
interface KvListSelector {
  prefix: KvKey;
}
interface KvCommitResult {
  ok: boolean;
}
interface KvAtomic {
  check(entry: KvEntry<unknown>): KvAtomic;
  set(key: KvKey, value: unknown): KvAtomic;
  delete(key: KvKey): KvAtomic;
  commit(): Promise<KvCommitResult>;
}
interface Kv {
  get<T>(key: KvKey): Promise<KvEntry<T> | null>;
  set(key: KvKey, value: unknown): Promise<KvCommitResult>;
  delete(key: KvKey): Promise<KvCommitResult>;
  list<T>(selector: KvListSelector, opts?: { limit?: number }): AsyncIterable<KvEntry<T>>;
  atomic(): KvAtomic;
  /** подписка на массив ключей: снапшот + каждое изменение */
  watch(keys: KvKey[]): ReadableStream<KvEntry<unknown>[]>;
}

let kvMode: 'deno' | 'memory' | 'sql' = 'memory';
/** 'booting' — фоновое подключение постоянного хранилища ещё идёт */
let kvBoot: 'booting' | 'ready' = 'booting';

/** KV поверх Map — аварийный режим (нет базы у приложения) и локальные
 *  тесты. Семантики те же: versionstamp монотонный, CAS честный. */
class MemoryKv implements Kv {
  #data = new Map<string, { value: unknown; vs: string; key: KvKey }>();
  #vs = 0;
  #watchers = new Map<string, Set<() => void>>();
  #ks(key: KvKey): string {
    return key.map((p) => `${typeof p}:${String(p)}`).join('|');
  }
  #bump(): string {
    this.#vs += 2;
    return String(this.#vs).padStart(16, '0') + '0000';
  }
  async #fire(keys: KvKey[]): Promise<void> {
    // уведомляем всех, кто смотрит ЛЮБОЙ из изменённых ключей
    const cbs = new Set<() => void>();
    for (const k of keys) {
      for (const cb of this.#watchers.get(this.#ks(k)) ?? []) cbs.add(cb);
    }
    for (const cb of cbs) cb();
  }
  async get<T>(key: KvKey): Promise<KvEntry<T> | null> {
    const hit = this.#data.get(this.#ks(key));
    if (!hit) return null;
    return { key, value: hit.value as T, versionstamp: hit.vs };
  }
  async set(key: KvKey, value: unknown): Promise<KvCommitResult> {
    const ks = this.#ks(key);
    const vs = this.#bump();
    this.#data.set(ks, { value, vs, key });
    await this.#fire([key]);
    return { ok: true };
  }
  async delete(key: KvKey): Promise<KvCommitResult> {
    const ks = this.#ks(key);
    const had = this.#data.delete(ks);
    if (had) await this.#fire([key]);
    return { ok: true };
  }
  async *list<T>(
    selector: KvListSelector,
    opts?: { limit?: number },
  ): AsyncIterable<KvEntry<T>> {
    const prefix = this.#ks(selector.prefix) + '|';
    let n = 0;
    for (const [ks, hit] of [...this.#data.entries()].sort(([a], [b]) =>
      a < b ? -1 : a > b ? 1 : 0,
    )) {
      if (!ks.startsWith(prefix)) continue;
      if (opts?.limit && n >= opts.limit) return;
      n++;
      const key = ks.split('|').map((p) => {
        const [type, ...rest] = p.split(':');
        const raw = rest.join(':');
        return type === 'number' ? Number(raw) : raw;
      });
      yield { key, value: hit.value as T, versionstamp: hit.vs };
    }
  }
  atomic(): KvAtomic {
    const ops: {
      kind: 'check' | 'set' | 'delete';
      entry?: KvEntry<unknown>;
      key?: KvKey;
      value?: unknown;
    }[] = [];
    const self = this;
    return {
      check(entry: KvEntry<unknown>) {
        ops.push({ kind: 'check', entry });
        return this;
      },
      set(key: KvKey, value: unknown) {
        ops.push({ kind: 'set', key, value });
        return this;
      },
      delete(key: KvKey) {
        ops.push({ kind: 'delete', key });
        return this;
      },
      async commit(): Promise<KvCommitResult> {
        for (const op of ops) {
          if (op.kind !== 'check' || !op.entry || !op.entry.key) continue;
          const cur = self.#data.get(self.#ks(op.entry.key));
          const curVs = cur ? cur.vs : null;
          if (curVs !== (op.entry.versionstamp ?? null)) return { ok: false };
        }
        const touched: KvKey[] = [];
        for (const op of ops) {
          if (op.kind === 'set' && op.key) {
            const vs = self.#bump();
            self.#data.set(self.#ks(op.key), { value: op.value, vs, key: op.key });
            touched.push(op.key);
          } else if (op.kind === 'delete' && op.key) {
            if (self.#data.delete(self.#ks(op.key))) touched.push(op.key);
          }
        }
        await self.#fire(touched);
        return { ok: true };
      },
    };
  }
  watch(keys: KvKey[]): ReadableStream<KvEntry<unknown>[]> {
    const snapshot = () =>
      keys.map((k) => {
        const hit = this.#data.get(this.#ks(k));
        return {
          key: k,
          value: hit ? hit.value : null,
          versionstamp: hit ? hit.vs : '00000000000000000000',
        };
      });
    let fire: (() => void) | null = null;
    return new ReadableStream({
      start: (ctrl) => {
        ctrl.enqueue(snapshot());
        fire = () => ctrl.enqueue(snapshot());
        for (const k of keys) {
          const set = this.#watchers.get(this.#ks(k)) ?? new Set();
          set.add(fire);
          this.#watchers.set(this.#ks(k), set);
        }
      },
      cancel: () => {
        if (!fire) return;
        for (const k of keys) {
          const set = this.#watchers.get(this.#ks(k));
          if (set) {
            set.delete(fire);
            if (set.size === 0) this.#watchers.delete(this.#ks(k));
          }
        }
      },
    });
  }
  /** снимок для миграции на постоянное хранилище (Task 42): ключи
   *  хранятся в исходном виде — переносим без потерь */
  *entries(): IterableIterator<{ key: KvKey; value: unknown }> {
    for (const { key, value } of this.#data.values()) {
      yield { key: [...key], value };
    }
  }
  size(): number {
    return this.#data.size;
  }
}

/** SQL-хранилище поверх Postgres (Task 39): постоянство для
 *  Deno Deploy без Deno KV. Один интерфейс Kv — остальной код
 *  сервера не меняется. Ключи — текст k = parts(encodeURIComponent)
 *  через '/'; versionstamp — монотонная последовательность
 *  mj_kv_vs_seq; CAS — SELECT ... FOR UPDATE в транзакции;
 *  watch — поллинг 2 c (потребитель дедупит по versionstamp). */
const SQL_POLL_MS = 2000;

type SqlTagged = {
  // deno-lint-ignore no-explicit-any
  <T = Record<string, unknown>>(
    strings: TemplateStringsArray,
    ...vals: unknown[]
  ): Promise<T[]>;
  begin<T>(fn: (tx: SqlTagged) => Promise<T>): Promise<T>;
  json(value: unknown): unknown;
};

interface SqlRow {
  k: string;
  v: unknown;
  vs: string | number;
}

class SqlKv implements Kv {
  #sql: SqlTagged;
  ready = false;

  constructor(sql: SqlTagged) {
    this.#sql = sql;
  }

  /** создать схему/таблицу (идемпотентно; схема mj — на хостах
   *  без public-схемы вроде filess.io) */
  async init(): Promise<void> {
    await this.#sql`CREATE SCHEMA IF NOT EXISTS mj`;
    await this.#sql`
      CREATE TABLE IF NOT EXISTS mj.mj_kv (
        k text PRIMARY KEY,
        v jsonb NOT NULL,
        vs bigint NOT NULL DEFAULT 0
      )`;
    await this.#sql`
      CREATE SEQUENCE IF NOT EXISTS mj.mj_kv_vs_seq AS bigint START 1000`;
    await this.#sql`CREATE INDEX IF NOT EXISTS mj_kv_k_idx ON mj.mj_kv (k)`;
    this.ready = true;
  }

  #k(key: KvKey): string {
    return key.map((p) => encodeURIComponent(String(p))).join('/');
  }

  async get<T>(key: KvKey): Promise<KvEntry<T> | null> {
    const rows = await this.#sql<SqlRow & { vs: string | number }>`
      SELECT k, v, vs FROM mj.mj_kv WHERE k = ${this.#k(key)}`;
    const r = rows[0];
    if (!r) return null;
    return { key, value: r.v as T, versionstamp: String(r.vs) };
  }

  async set(key: KvKey, value: unknown): Promise<KvCommitResult> {
    const k = this.#k(key);
    await this.#sql`
      INSERT INTO mj.mj_kv (k, v, vs)
      VALUES (${k}, ${this.#sql.json(value)}::jsonb, nextval('mj.mj_kv_vs_seq'))
      ON CONFLICT (k) DO UPDATE
        SET v = EXCLUDED.v, vs = EXCLUDED.vs`;
    return { ok: true };
  }

  async delete(key: KvKey): Promise<KvCommitResult> {
    await this.#sql`DELETE FROM mj.mj_kv WHERE k = ${this.#k(key)}`;
    return { ok: true };
  }

  async *list<T>(
    selector: KvListSelector,
    opts?: { limit?: number },
  ): AsyncIterable<KvEntry<T>> {
    const prefix = selector.prefix
      .map((p) => encodeURIComponent(String(p)))
      .join('/');
    const lim = opts?.limit;
    const rows = lim != null
      ? await this.#sql<{ k: string; v: T; vs: string | number }>`
          SELECT k, v, vs FROM mj.mj_kv
          WHERE starts_with(k, ${prefix})
          ORDER BY k LIMIT ${lim}`
      : await this.#sql<{ k: string; v: T; vs: string | number }>`
          SELECT k, v, vs FROM mj.mj_kv
          WHERE starts_with(k, ${prefix})
          ORDER BY k`;
    for (const r of rows) {
      const key = r.k.split('/').map((p) => decodeURIComponent(p));
      yield { key, value: r.v, versionstamp: String(r.vs) };
    }
  }

  /** лобби-скан (Task 45): проекция на стороне SQL. Полный list()
   *  гнал ~50-100 КБ JSON ВСЕХ комнат каждый тик лобби — узкое
   *  место пропускной способности filess.io (tick 2-3 c, пул
   *  соединений насыщался — join/create по 8 c). Теперь база сама
   *  фильтрует ждущие открытые комнаты и присылает пару сотен
   *  байт. Фильтрация по статусу — в SQL (seq-scan локален для
   *  базы и бесплатен), сорт/лимит — как раньше в JS. */
  async lobbyWaiting(): Promise<
    {
      code: string;
      level: number;
      hostName: string;
      hue: number;
      createdAt: number;
      players: number;
      hostLastSeen: number;
    }[]
  > {
    const rows = await this.#sql<{
      k: string;
      level: number | null;
      hostName: string | null;
      hue: number | null;
      createdAt: string | null;
      players: number | null;
      hostLastSeen: string | null;
    }>`
      SELECT k,
             COALESCE(v->>'level', '1')::int AS level,
             COALESCE(v->'players'->0->>'name', '') AS "hostName",
             COALESCE(v->'players'->0->>'hue', '30')::int AS hue,
             COALESCE(v->>'createdAt', '0')::bigint AS "createdAt",
             COALESCE(jsonb_array_length(v->'players'), 0) AS players,
             COALESCE(v->'players'->0->>'lastSeen', '0')::bigint AS "hostLastSeen"
      FROM mj.mj_kv
      WHERE starts_with(k, 'room/')
        AND v->>'status' = 'waiting'
        AND v->>'visibility' = 'open'`;
    return rows.map((r) => ({
      code: r.k.split('/')[1] ?? '',
      level: Number(r.level ?? 1),
      hostName: String(r.hostName ?? ''),
      hue: Number(r.hue ?? 30),
      createdAt: Number(r.createdAt ?? 0),
      players: Number(r.players ?? 0),
      hostLastSeen: Number(r.hostLastSeen ?? 0),
    }));
  }

  /** ГОРЯЧИЕ ПУТИ (Task 45): атомарные JSONB-патчи в ОДИН запрос.
   *  Раньше каждое присутствие/событие пары шло полной CAS-схемой
   *  (SELECT → BEGIN → SELECT FOR UPDATE → UPDATE → COMMIT ≈ 5 RTT
   *  ≈ 1.1 c при RTT 225 мс): во время живого матча очередь на
   *  две связи росла до 30-50 c, пинги не пробивались — «вылетает
   *  во время игры по сети». jsonb_set трогает ТОЛЬКО нужные поля
   *  — гонок с другими записями нет. */
  async touchPlayerSeen(code: string, pid: string): Promise<void> {
    const t = Date.now();
    await this.#sql`
      UPDATE mj.mj_kv SET v = jsonb_set(
        v, '{players}',
        COALESCE((
          SELECT jsonb_agg(
            CASE WHEN p.value->>'id' = ${pid}
              THEN jsonb_set(p.value, '{lastSeen}', to_jsonb(${t}::bigint))
              ELSE p.value END
            ORDER BY p.ordinality
          )
          FROM jsonb_array_elements(mj.mj_kv.v->'players')
            WITH ORDINALITY p(value, ordinality)
        ), '[]'::jsonb)
      )
      WHERE mj.mj_kv.k = ${'room/' + code}
        AND EXISTS (
          SELECT 1 FROM jsonb_array_elements(mj.mj_kv.v->'players') e
          WHERE e->>'id' = ${pid}
        )`;
  }

  /** событие «собрал пару»: lastSeen+очки+пары+lastEvent одним
   *  UPDATE'ом (1 RTT); комнату для пуши перечитывает вызывающий */
  async applyMatchEvent(
    code: string,
    pid: string,
    score: number,
    pairsDone: number,
    lastEvent: Record<string, unknown>,
  ): Promise<boolean> {
    const t = Date.now();
    const sc = Math.max(0, Math.floor(score));
    const pr = Math.max(0, Math.floor(pairsDone));
    const rows = await this.#sql<{ ok: boolean }>`
      UPDATE mj.mj_kv SET v = jsonb_set(
        jsonb_set(v, '{lastEvent}', ${this.#sql.json(lastEvent)}::jsonb),
        '{players}',
        COALESCE((
          SELECT jsonb_agg(
            CASE WHEN p.value->>'id' = ${pid}
              THEN jsonb_set(jsonb_set(jsonb_set(
                p.value,
                '{lastSeen}', to_jsonb(${t}::bigint)),
                '{score}', to_jsonb(${sc}::int)),
                '{pairsDone}', to_jsonb(${pr}::int))
              ELSE p.value END
            ORDER BY p.ordinality
          )
          FROM jsonb_array_elements(mj.mj_kv.v->'players')
            WITH ORDINALITY p(value, ordinality)
        ), '[]'::jsonb)
      )
      WHERE mj.mj_kv.k = ${'room/' + code}
        AND EXISTS (
          SELECT 1 FROM jsonb_array_elements(mj.mj_kv.v->'players') e
          WHERE e->>'id' = ${pid}
        )
      RETURNING true AS ok`;
    return rows.length > 0;
  }

  atomic(): KvAtomic {
    interface Op {
      kind: 'check' | 'set' | 'delete';
      entry?: KvEntry<unknown>;
      key?: KvKey;
      value?: unknown;
    }
    const ops: Op[] = [];
    const self = this;
    return {
      check(entry: KvEntry<unknown>) {
        ops.push({ kind: 'check', entry });
        return this;
      },
      set(key: KvKey, value: unknown) {
        ops.push({ kind: 'set', key, value });
        return this;
      },
      delete(key: KvKey) {
        ops.push({ kind: 'delete', key });
        return this;
      },
      async commit(): Promise<KvCommitResult> {
        if (ops.length === 0) return { ok: true };
        try {
          await self.#sql.begin(async (tx) => {
            // строгие вставки: check с «ключа нет» + set того же ключа
            // — обычный INSERT (конфликт = честный проигрыш CAS)
            const strictInsert = new Set<string>();
            for (const op of ops) {
              if (op.kind !== 'check' || !op.entry || !op.entry.key) continue;
              const k = self.#k(op.entry.key);
              const want = op.entry.versionstamp ?? null;
              const rows = await tx<{ vs: string | number | null }>`
                SELECT vs FROM mj.mj_kv WHERE k = ${k} FOR UPDATE`;
              const cur = rows[0] ? String(rows[0].vs) : null;
              if (cur !== (want === null ? null : String(want))) {
                throw new Error('kv-cas-mismatch');
              }
              if (cur === null) strictInsert.add(k);
            }
            for (const op of ops) {
              if (op.kind === 'set' && op.key) {
                const k = self.#k(op.key);
                if (strictInsert.has(k)) {
                  await tx`
                    INSERT INTO mj.mj_kv (k, v, vs)
                    VALUES (${k}, ${self.#sql.json(op.value)}::jsonb, nextval('mj.mj_kv_vs_seq'))`;
                } else {
                  await tx`
                    INSERT INTO mj.mj_kv (k, v, vs)
                    VALUES (${k}, ${self.#sql.json(op.value)}::jsonb, nextval('mj.mj_kv_vs_seq'))
                    ON CONFLICT (k) DO UPDATE
                      SET v = EXCLUDED.v, vs = EXCLUDED.vs`;
                }
              } else if (op.kind === 'delete' && op.key) {
                await tx`DELETE FROM mj.mj_kv WHERE k = ${self.#k(op.key)}`;
              }
            }
          });
          return { ok: true };
        } catch (_e) {
          return { ok: false };
        }
      },
    };
  }

  watch(keys: KvKey[]): ReadableStream<KvEntry<unknown>[]> {
    const kk = keys.map((k) => this.#k(k));
    let timer: ReturnType<typeof setInterval> | null = null;
    let closed = false;
    return new ReadableStream<KvEntry<unknown>[]>({
      start: (ctrl) => {
        const poll = async () => {
          if (closed) return;
          try {
            const out: KvEntry<unknown>[] = [];
            for (let i = 0; i < kk.length; i++) {
              const rows = await this.#sql<SqlRow>`
                SELECT k, v, vs FROM mj.mj_kv WHERE k = ${kk[i]}`;
              const r = rows[0];
              out.push(
                r
                  ? {
                      key: keys[i],
                      value: r.v,
                      versionstamp: String(r.vs),
                    }
                  : {
                      key: keys[i],
                      value: null,
                      versionstamp: '00000000000000000000',
                    },
              );
            }
            ctrl.enqueue(out);
          } catch {
            // SQL моргнул — следующий тик
          }
        };
        void poll();
        timer = setInterval(() => void poll(), SQL_POLL_MS);
      },
      cancel: () => {
        closed = true;
        if (timer) clearInterval(timer);
      },
    });
  }
}

/** открыть KV БЕЗ блокировки старта (Task 42). Сервер слушает
 * мгновенно с MemoryKv; постоянное хранилище поднимается фоном.
 *  Приоритеты:
 *   - на Deploy (DENO_DEPLOYMENT_ID/DENO_REGION): сначала нативный
 *     Deno.openKv() — коннектится к KV, провиженному через Databases
 *     (лучшая связка: быстро, бесплатно, без внешних сервисов);
 *     затем SQL по DATABASE_URL (Env Variables / вшитая строка);
 *   - локально: сначала SQL (DATABASE_URL / вшитая строка — как в
 *     Task 41), затем локальный Deno.openKv() (dev-файл), затем память.
 *  SQL-ретраи — с бэкоффом 3с→6с→12с…≤ 30с, до бесконечности:
 *  изолят живёт, пока есть трафик. */
const SQL_RETRY_CAP_MS = 30_000;

/** Строка подключения ЗАШИТА только в download-версии файла (Task 41).
 *  В репо-версии пуста — приоритет у DATABASE_URL из окружения. */
const EMBEDDED_DB_URL = '';

const ON_DEPLOY = Boolean(
  Deno.env.get('DENO_DEPLOYMENT_ID') ?? Deno.env.get('DENO_REGION'),
);

const sleepBoot = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** одна попытка SQL-подключения (без ретраев) */
async function tryOpenSql(dbUrl: string): Promise<Kv | null> {
  try {
    const { default: postgres } = await import('npm:postgres@3.4.5');
    let url = dbUrl;
    // TLS: добавляем sslmode=require только хостам, которые его
    // поддерживают (Neon/Supabase/Aiven/облака). filess.io и
    // «голые» хосты оставляем как есть — иначе рукопожатие падает
    if (
      !/[?&]sslmode=/.test(url) &&
      !/localhost|127\.0\.0\.1/.test(url) &&
      /neon\.tech|supabase|aiven|amazonaws|\.aws\.|azure|render\.com|railway|fly\.io|koyeb|alwaysdata|cr\.dev|cockroach/i.test(url)
    ) {
      url += (url.includes('?') ? '&' : '?') + 'sslmode=require';
    }
    const sql = postgres(url, {
      // Task 45: filess.io Shared — rolconnlimit = 5 на ВСЮ роль.
      // Deno Deploy поднимает несколько изолятов, каждый со своим
      // пулом: 4 соединения на изолят пробивали лимит («too many
      // connections») — изолят не мог читать базу: друзья «терялись»,
      // матчи умирали. max:2 → до 2 изолятов в лимите; idle-соединения
      // закрываются через 20 c (простаивающие изоляты не держат базу).
      max: 2,
      idle_timeout: 20,
      connect_timeout: 8,
      // подготовленные выражения мешают pg_bouncer-пулам (Neon pooling)
      prepare: false,
    }) as unknown as SqlTagged;
    const sqlKv = new SqlKv(sql);
    await sqlKv.init();
    return sqlKv;
  } catch (err) {
    const msg = err instanceof Error ? (err.message || String(err)) : String(err);
    console.warn(`[kv] SQL-попытка не вышла (${msg.slice(0, 120)})`);
    return null;
  }
}

/** нативный Deno KV: на Deploy — провиженный через Databases,
 *  локально — файловая база в каталоге запуска (dev).
 *  Task 45: ГОНЯЕМ ПО ТАЙМАУТУ (10 c) — на Deploy без провиженной
 *  базы Deno.openKv() может ЗАВИСНУТЬ (не резолвится и не
 *  отвергается) — наблюдали на проде: boot навечно «booting»,
 *  SQL-фолбэк не стартовал. Теперь зависание не блокирует
 *  подключение вшитой SQL-строки. */
const DENO_KV_TIMEOUT_MS = 10_000;

async function tryOpenDenoKv(): Promise<Kv | null> {
  try {
    const real = await Promise.race([
      Deno.openKv(),
      new Promise<never>((_, rej) =>
        setTimeout(
          () => rej(new Error('openKv timeout')),
          DENO_KV_TIMEOUT_MS,
        )
      ),
    ]);
    const wrap = real as unknown as Kv;
    // sanity: все методы на месте?
    if (
      typeof wrap.get !== 'function' ||
      typeof wrap.atomic !== 'function' ||
      typeof wrap.watch !== 'function'
    ) {
      throw new Error('kv api mismatch');
    }
    return wrap;
  } catch (err) {
    console.warn(
      '[kv] Deno.openKv() не смог открыться: ' +
        (err instanceof Error ? err.message : String(err)),
    );
    return null;
  }
}

/** миграция памяти на постоянное хранилище + смена биндинга.
 *  Двойной проход: второй ловит записи, случившиеся во время первого
 *  (окно в миллисекунды; данные игровых комнат, не банк). */
async function kvUpgrade(store: Kv, mode: 'deno' | 'sql'): Promise<void> {
  const mem = kv instanceof MemoryKv ? kv : null;
  let moved = 0;
  for (let pass = 0; pass < 2; pass++) {
    if (!mem || mem.size() === 0) break;
    let passMoved = 0;
    for (const e of mem.entries()) {
      await store.set(e.key, e.value);
      passMoved++;
    }
    moved += passMoved;
    if (passMoved === 0) break;
  }
  kv = store;
  kvMode = mode;
  kvBoot = 'ready';
  console.log(
    `[kv] постоянное хранилище поднято (kv=${mode})` +
      (moved > 0 ? ` — перенесено записей из памяти: ${moved}` : ''),
  );
}

async function kvBackgroundInit(): Promise<void> {
  if (Deno.env.get('MJ_KV') === 'memory') {
    kvMode = 'memory';
    kvBoot = 'ready';
    console.warn('[kv] MJ_KV=memory — режим памяти (один изолят, для отладки)');
    return;
  }
  const dbUrl = Deno.env.get('DATABASE_URL')?.trim() || EMBEDDED_DB_URL;

  if (ON_DEPLOY) {
    const dkv = await tryOpenDenoKv();
    if (dkv) {
      await kvUpgrade(dkv, 'deno');
      return;
    }
    console.warn(
      '[kv] Deno KV не провижен. Рекомендую: консоль → Databases → Provision Database → Deno KV → назначить приложению — тогда Deno.openKv() подключится сам, без внешних баз',
    );
  }

  if (dbUrl) {
    let delay = 3000;
    for (let attempt = 1; ; attempt++) {
      const store = await tryOpenSql(dbUrl);
      if (store) {
        console.log(
          `[kv] SQL-хранилище подключено (Postgres, попытка ${attempt}) — друзья, чаты и комнаты постоянны`,
        );
        await kvUpgrade(store, 'sql');
        return;
      }
      console.warn(
        `[kv] SQL попытка ${attempt} не вышла — повтор через ${Math.round(delay / 1000)} с`,
      );
      await sleepBoot(delay);
      delay = Math.min(delay * 2, SQL_RETRY_CAP_MS);
    }
  }

  if (!ON_DEPLOY) {
    const dkv = await tryOpenDenoKv();
    if (dkv) {
      await kvUpgrade(dkv, 'deno');
      return;
    }
  }

  kvBoot = 'ready';
  if (!dbUrl) {
    console.warn('[kv] НЕТ DATABASE_URL — постоянное хранилище недоступно!');
    console.warn('[kv] Друзья/чаты/комнаты будут жить только в памяти одного изолята.');
    console.warn(
      '[kv] На Deno Deploy: Databases → Provision Database → Deno KV (или задай DATABASE_URL).',
    );
  }
  console.warn('[kv] Работаем в РЕЖИМЕ ПАМЯТИ — комнаты сбросятся при рестарте изолята.');
}

let kv: Kv = new MemoryKv();
void kvBackgroundInit();

/* ============================ УТИЛИТЫ ============================ */

const now = () => Date.now();
const LOG = (msg: string) => console.log(`${new Date().toISOString().slice(11, 23)} ${msg}`);
const rndId = () =>
  Array.from({ length: 8 }, () => Math.floor(Math.random() * 36).toString(36))
    .join('');
const rndHue = () => Math.floor(Math.random() * 360);
const clamp = (n: number, lo: number, hi: number) =>
  Math.min(hi, Math.max(lo, n));

function timeForLevel(level: number): number {
  const pairs = PAIRS_BY_LEVEL[(clamp(level, 1, 999) - 1) % PAIRS_BY_LEVEL.length];
  return clamp(pairs * TIME_PER_PAIR_MS, TIME_MIN_MS, TIME_MAX_MS);
}

function sanitizeName(raw: unknown): string {
  const s = typeof raw === 'string' ? raw.trim().replace(/\s+/g, ' ') : '';
  const cut = [...s].slice(0, 16).join('');
  return cut.length > 0 ? cut : 'Игрок';
}

function normalizeCode(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const c = raw.trim().toUpperCase();
  return c.length === CODE_LEN && [...c].every((ch) => CODE_CHARS.includes(ch))
    ? c
    : null;
}

function newSeed(): number {
  return Math.floor(Math.random() * 0x7fffffff);
}

function newCode(): string {
  return Array.from(
    { length: CODE_LEN },
    () => CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)],
  ).join('');
}

/** глубокая копия (KV-значения — плоский JSON, но advanceBy меняется) */
function clone<T>(v: T): T {
  return structuredClone(v);
}

/** публичная вьюха комнаты для клиента */
function view(r: RoomState): RoomView {
  const t = now();
  return {
    code: r.code,
    status: r.status,
    level: r.level,
    seed: r.seed,
    hostId: r.hostId,
    timeTotalMs: r.timeTotalMs,
    startedAt: r.startedAt,
    serverNow: t,
    players: r.players.map((p) => ({
      id: p.id,
      name: p.name,
      hue: p.hue,
      score: Math.round(p.score),
      pairsDone: p.pairsDone,
      online: t - p.lastSeen < PRESENCE_MS,
      finished: p.finished,
      wins: p.wins,
      uid: p.uid,
    })),
    result: r.result ? { ...r.result } : null,
    visibility: r.visibility,
    advanceOffers: Object.entries(r.advanceBy).map(([playerId, kind]) => ({
      playerId,
      kind,
    })),
  };
}

/* ==================== СОКЕТЫ ИЗОЛЯТА + ПОДПИСКИ ==================== */

interface Sock {
  ws: WebSocket;
  uid: string;
  name: string;
  /** привязанная комната (code) и игрок */
  roomCode: string | null;
  playerId: string | null;
  /** монотонный счётчик смены привязки: поздний hello
   *  не затирает свежую привязку от create/join (гонка) */
  bindEpoch: number;
  /** подписан на лобби открытых игр */
  lobby: boolean;
  /** активный тикет матчмейкинга */
  mmTicket: string | null;
  /** когда последний раз писали маркер присутствия в KV (друзья) */
  lastOnlineTouch: number;
  alive: boolean;
}

const sockets = new Set<Sock>();

/** атомарная смена привязки сокета к комнате (последний выигрывает) */
function bindSock(s: Sock, code: string | null, pid: string | null): void {
  s.bindEpoch++;
  s.roomCode = code;
  s.playerId = pid;
}

/** комната → {lastPushedVs, lastEventAt, watch} — подписка изолята */
interface RoomWatch {
  vs: string;
  lastEventAt: number;
  reader?: ReadableStreamDefaultReader<KvEntry<unknown>[]>;
  refs: number;
  /** с какого момента в комнате нет НИ ОДНОГО локального сокета
   *  (Task 45; 0 — сокеты есть). См. WATCH_EMPTY_GRACE_MS. */
  emptySince: number;
}
const roomWatches = new Map<string, RoomWatch>();

/** тикет матчмейкинга → подписка (когда «подобрали» из другого изолята) */
const ticketWatches = new Map<
  string,
  ReadableStreamDefaultReader<KvEntry<unknown>[]>
>();

function send(s: Sock, m: Record<string, unknown>): void {
  if (!s.alive) return;
  try {
    s.ws.send(JSON.stringify(m));
  } catch {
    // сокет уже мёртв — приберём на close
  }
}

/** кому из локальных сокетов нужна эта комната */
function localRoomSocks(code: string): Sock[] {
  return [...sockets].filter((s) => s.roomCode === code);
}

/** подписаться на изменения комнаты (kv.watch) и разослать вьюхи */
function ensureRoomWatch(code: string): void {
  let w = roomWatches.get(code);
  if (!w) {
    w = { vs: '', lastEventAt: 0, refs: 0, emptySince: 0 };
    roomWatches.set(code, w);
  }
  w.refs++;
  if (w.reader) return;
  try {
    const stream = kv.watch([['room', code]]);
    w.reader = stream.getReader();
    const pump = async () => {
      const rw = roomWatches.get(code);
      const reader = rw?.reader;
      if (!reader) return;
      try {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) return;
          const entry = value?.[0];
          if (!entry) continue;
          const vs = entry.versionstamp;
          const room = entry.value as RoomState | null;
          const cur = roomWatches.get(code);
          if (!cur) return;
          if (vs === cur.vs) continue; // уже разослали это изменение
          cur.vs = vs;
          if (!room) continue; // комнату удалили — клиент узнает сам
          const v = view(room);
          const targets = localRoomSocks(code);
          for (const s of targets) {
            send(s, { t: 'room', view: v });
            // событие «соперник собрал пару» — с дедупом по времени
            if (
              room.lastEvent &&
              room.lastEvent.at > cur.lastEventAt &&
              room.lastEvent.playerId !== s.playerId
            ) {
              send(s, {
                t: 'event',
                kind: 'match',
                playerId: room.lastEvent.playerId,
                tile1Id: room.lastEvent.tile1Id,
                tile2Id: room.lastEvent.tile2Id,
                score: room.lastEvent.score,
                pairsDone: room.lastEvent.pairsDone,
              });
            }
          }
          if (room.lastEvent && room.lastEvent.at > cur.lastEventAt) {
            cur.lastEventAt = room.lastEvent.at;
          }
        }
      } catch {
        // watch умер (KV недоступен) — свипер продолжит раз в 1.5 c
        const c = roomWatches.get(code);
        if (c) c.reader = undefined;
      }
    };
    void pump();
  } catch {
    // watch не поддерживается — свипер полингом раз в 1.5 c
  }
}

function releaseRoomWatch(code: string): void {
  const w = roomWatches.get(code);
  if (!w) return;
  w.refs = Math.max(0, w.refs - 1);
  if (w.refs > 0) return;
  roomWatches.delete(code);
  try {
    w.reader?.cancel();
  } catch {
    // ignore
  }
}

/** погасить watch вне зависимости от refs (Task 45): комнату
 *  бросили — локальных сокетов нет дольше grace. Создаётся заново
 *  автоматически при следующем hello/bind — данные не теряем. */
function hardReleaseRoomWatch(code: string): void {
  const w = roomWatches.get(code);
  if (!w) return;
  w.refs = 0;
  roomWatches.delete(code);
  try {
    w.reader?.cancel();
  } catch {
    // ignore
  }
}

/* ==================== ЧТЕНИЕ/ЗАПИСЬ КОМНАТ (CAS) ==================== */

async function getRoom(code: string): Promise<RoomState | null> {
  const e = await kv.get<RoomState>(['room', code]);
  return e?.value ?? null;
}

/** чтение СВЕЖЕЙ комнаты: сразу после create KV на другом изоляте
 *  может ещё не видеть ключ — короткие ретраи с паузами */
async function getFreshRoom(code: string): Promise<RoomState | null> {
  for (let i = 0; i < FRESH_ROOM_RETRIES; i++) {
    const r = await getRoom(code);
    if (r) return r;
    if (i === FRESH_ROOM_RETRIES - 1) return null;
    await new Promise((res) => setTimeout(res, 250 * (i + 1)));
  }
  return null;
}

/** изменить комнату через CAS; fn возвращает новое состояние,
 *  'abort' — без изменений (успех без записи), 'delete' — удалить.
 *  ВАЖНО (Фидбек «связь теряется»): два игрока поллят комнату каждые
 *  ~4 c, каждый полл — запись (lastSeen); одновременные записи из
 *  разных изолятов конфликтуют по versionstamp. Если ретраи исчерпаны,
 *  это НЕ значит «комнаты нет» — возвращаем её с contention:true,
 *  чтобы вызывающие отвечали вьюхой, а не страшным ROOM_NOT_FOUND
 *  (из-за которого клиент ронял матч после 3 промахов подряд). */
async function mutateRoom(
  code: string,
  fn: (r: RoomState) => RoomState | 'abort' | 'delete',
): Promise<{ ok: boolean; room: RoomState | null; changed?: boolean; deleted?: boolean; contention?: boolean }> {
  for (let i = 0; i < 10; i++) {
    const entry = await kv.get<RoomState>(['room', code]);
    const cur = entry?.value ?? null;
    if (!cur) return { ok: false, room: null };
    const next = fn(clone(cur));
    if (next === 'abort') return { ok: true, room: cur, changed: false };
    if (next === 'delete') {
      await kv.delete(['room', code]);
      return { ok: true, room: null, deleted: true, changed: true };
    }
    const res = await kv.atomic()
      .check(entry as KvEntry<unknown>)
      .set(['room', code], next)
      .commit();
    if (res.ok) return { ok: true, room: next, changed: true };
    // конфликт — крошечная пауза (растёт) и снова
    await new Promise((r) => setTimeout(r, 8 + i * 12));
  }
  // исчерпали ретраи: комната почти наверняка жива — не даём
  // вызывающим врать «ROOM_NOT_FOUND»
  const last = await kv.get<RoomState>(['room', code]);
  return last?.value
    ? { ok: false, room: last.value, contention: true }
    : { ok: false, room: null };
}

/** разослать вьюху локальным сокетам комнаты (свой вклад изолята) */
function pushLocal(code: string, room: RoomState): void {
  const w = roomWatches.get(code);
  const v = view(room);
  for (const s of localRoomSocks(code)) {
    send(s, { t: 'room', view: v });
    if (
      room.lastEvent &&
      (!w || room.lastEvent.at > w.lastEventAt) &&
      room.lastEvent.playerId !== s.playerId
    ) {
      send(s, {
        t: 'event',
        kind: 'match',
        playerId: room.lastEvent.playerId,
        tile1Id: room.lastEvent.tile1Id,
        tile2Id: room.lastEvent.tile2Id,
        score: room.lastEvent.score,
        pairsDone: room.lastEvent.pairsDone,
      });
    }
  }
  if (w && room.lastEvent && room.lastEvent.at > w.lastEventAt) {
    w.lastEventAt = room.lastEvent.at;
  }
}

/* ==================== АВТО-ИСХОДЫ И ЧИСТКА ==================== */

/** применить к комнате авт-исходы; null — без изменений,
 *  'delete' — комнату пора убрать */
function autoRules(r: RoomState, t: number): RoomState | null | 'delete' {
  if (t - r.createdAt > ROOM_TTL_MS) return 'delete';
  if (r.status === 'waiting') {
    if (t - r.createdAt > WAITING_TTL_MS) return 'delete';
    const host = r.players[0];
    if (host && t - host.lastSeen > WAITING_HOST_STALE_MS) return 'delete';
    return null;
  }
  if (r.status !== 'playing') return null;
  // отсчёт ещё не начался (интро) — отключения не засчитываем
  if (t < r.startedAt) return null;
  for (const p of r.players) {
    const other = r.players.find((x) => x.id !== p.id);
    if (other && t - p.lastSeen > ONLINE_GRACE_MS) {
      return finishRoom(r, other.id, 'disconnect', t);
    }
  }
  if (t > r.startedAt + r.timeTotalMs) {
    const [a, b] = r.players;
    if (!a || !b) return null;
    const winnerId = a.pairsDone !== b.pairsDone
      ? (a.pairsDone > b.pairsDone ? a.id : b.id)
      : (a.score >= b.score ? a.id : b.id);
    return finishRoom(r, winnerId, 'timeout', t);
  }
  return null;
}

function finishRoom(
  r: RoomState,
  winnerId: string,
  reason: RoomFinishReason,
  t: number,
): RoomState {
  if (r.status !== 'playing') return r;
  const w = r.players.find((p) => p.id === winnerId);
  if (w) w.wins += 1; // счёт серии побед
  r.status = 'result';
  r.result = { winnerId, reason };
  r.lastEvent = null;
  console.log(`[room] finish ${r.code} · ${reason} · победил «${w?.name ?? '?'}»`);
  void t;
  return r;
}

/** свипер: досматривает авт-исходы комнат с локальными сокетами.
 *  Пушим локально ТОЛЬКО если watch недоступен (фолбэк).
 *  Task 39: чистка тикетов — только когда на изоляте есть живые
 *  сокеты (иначе SQL-база без дела не будится — Neon не тратит
 *  compute-часы на пустых изолятах). */
let sweepBusy = false;
async function sweep(): Promise<void> {
  // Task 45: не запускаем второй свип, пока первый не дошёл — иначе
  // при долгом SQL они накладываются друг на друга и душат пул
  if (sweepBusy) return;
  sweepBusy = true;
  try {
  const t = now();
  for (const code of [...roomWatches.keys()]) {
    // Task 45: watch без единого локального сокета — живёт щедрый
    // grace на реконнекты, затем гаснем (иначе брошенные комнаты
    // поллят SQL вечно и душат пул соединений — таймауты живых
    // игроков). Автоправила для комнат без watch досматривает
    // janitor, вьюхи бросившим игрокам не нужны.
    const w = roomWatches.get(code);
    if (w) {
      if (localRoomSocks(code).length > 0) w.emptySince = 0;
      else if (w.emptySince === 0) w.emptySince = t;
      else if (t - w.emptySince > WATCH_EMPTY_GRACE_MS) {
        hardReleaseRoomWatch(code);
        continue;
      }
    }
    const res = await mutateRoom(code, (r) => autoRules(r, t) ?? 'abort');
    if (!res.ok && res.room === null) {
      // комнаты нет — уведомлять некого, убираем подписку если сокеты ушли
      if (localRoomSocks(code).length === 0) releaseRoomWatch(code);
      continue;
    }
    if (res.changed && res.room && !roomWatches.get(code)?.reader) {
      pushLocal(code, res.room);
    }
  }
    // тикеты: мёртвые — вон (только при живых сокетах — см. комментарий)
    if (sockets.size > 0) {
      try {
        for await (const e of kv.list<TicketState>({ prefix: ['mm'] })) {
          const tk = e.value;
          if (tk && t - tk.lastSeen > TICKET_TTL_MS) await kv.delete(e.key);
        }
      } catch {
        // KV моргнул — в следующий тик
      }
    }
  } finally {
    sweepBusy = false;
  }
}

/** janitor: протухшие комнаты ВСЕ (даже без локальных сокетов).
 *  Task 39: с SQL-базой ходим только при живых сокетах (экономия
 *  compute-часов Neon) + редкий фоновый заход раз в 30 минут —
 *  чтобы совсем заброшенные комнаты всё же убирались. */
async function janitor(): Promise<void> {
  const t = now();
  try {
    for await (const e of kv.list<RoomState>({ prefix: ['room'] })) {
      const r = e.value;
      if (!r) continue;
      const next = autoRules(r, t);
      if (next === 'delete') await kv.delete(e.key);
      else if (next && next !== r) {
        await kv.atomic().check(e as KvEntry<unknown>).set(e.key, next).commit();
      } else if (next === null) {
        // Task 45: РАНЕЕ здесь был set(e.key, null) — janitor
        // ЗАТИРАЛ ЗДОРОВЫЕ КОМНАТЫ (autoRules(null) ≠ r — и ветка
        // писала null): живой матч умирал «Комната недоступна» каждые
        // ~5 минут («вылетает во время игры по сети»). Теперь null —
        // «без изменений», НЕ пишем ничего.
      }
    }
  } catch {
    // KV моргнул — в следующий заход
  }
}

/* ==================== ЛОББИ ОТКРЫТЫХ ИГР ==================== */

async function listOpenRooms(): Promise<OpenRoomInfo[]> {
  const t = now();
  const out: OpenRoomInfo[] = [];
  try {
    // SQL-проекция (Task 45): см. SqlKv.lobbyWaiting — качаем только
    // ждущие открытые комнаты парой сотен байт, а не весь JSON всех
    // комнат (~50-100 КБ на каждый тик лобби — душило filess.io)
    if (kv instanceof SqlKv && typeof kv.lobbyWaiting === 'function') {
      for (const r of await kv.lobbyWaiting()) {
        if (r.players >= 2) continue;
        if (t - r.hostLastSeen > WAITING_HOST_STALE_MS) continue;
        out.push({
          code: r.code,
          level: r.level,
          hostName: r.hostName,
          hue: r.hue,
          createdAt: r.createdAt,
          players: r.players,
        });
      }
    } else {
      for await (const e of kv.list<RoomState>({ prefix: ['room'] })) {
        const r = e.value;
        if (!r || r.status !== 'waiting' || r.visibility !== 'open') continue;
        const host = r.players[0];
        if (!host || r.players.length >= 2) continue;
        if (t - host.lastSeen > WAITING_HOST_STALE_MS) continue;
        out.push({
          code: r.code,
          level: r.level,
          hostName: host.name,
          hue: host.hue,
          createdAt: r.createdAt,
          players: r.players.length,
        });
      }
    }
  } catch {
    // KV моргнул — покажем прошлый список
  }
  out.sort((a, b) => a.createdAt - b.createdAt);
  return out.slice(0, OPEN_LIST_MAX);
}

/** ищущие быстрый матч: живые тикеты очереди (для плашки
 *  «ждёт игру» в главном меню других игроков) */
async function listSearching(): Promise<{
  name: string;
  level: number;
  hue: number;
  createdAt: number;
}[]> {
  const t = now();
  const out: { name: string; level: number; hue: number; createdAt: number }[] =
    [];
  try {
    for await (const e of kv.list<TicketState>({ prefix: ['mm'] })) {
      const tk = e.value;
      if (!tk || tk.paired) continue;
      if (t - tk.lastSeen > TICKET_TTL_MS) continue;
      out.push({
        name: tk.name,
        level: tk.level,
        hue: tk.hue,
        createdAt: tk.createdAt,
      });
    }
  } catch {
    // KV моргнул — покажем прошлый список
  }
  out.sort((a, b) => a.createdAt - b.createdAt);
  return out.slice(0, 10);
}

let lobbyTimer: ReturnType<typeof setInterval> | null = null;
function ensureLobbyLoop(): void {
  const need = [...sockets].some((s) => s.lobby);
  if (!need) {
    if (lobbyTimer !== null) {
      clearInterval(lobbyTimer);
      lobbyTimer = null;
    }
    return;
  }
  if (lobbyTimer !== null) return;
  let busy = false;
  const tick = async () => {
    if (![...sockets].some((s) => s.lobby)) return;
    // Task 45: скан лобби на filess.io — до секунд (RTT 225 мс +
    // перенос JSON всех комнат). Тик каждые 2 c длиной 2-3 c
    // насыщал пул соединений насмерть — join/create отвечали
    // по 8 c («вылетает во время игры»). Теперь: реже (5 c), без
    // наложения (busy-guard) — лобби обновляется чуть ленивее,
    // зато живые запросы не ждут.
    if (busy) return;
    busy = true;
    try {
      const [rooms, searching] = await Promise.all([
        listOpenRooms(),
        listSearching(),
      ]);
      for (const s of sockets) {
        if (s.lobby) send(s, { t: 'lobby', rooms, searching });
      }
    } finally {
      busy = false;
    }
  };
  void tick();
  lobbyTimer = setInterval(() => void tick(), 5000);
}

/* ==================== ДРУЗЬЯ (Task 37) ====================
 *
 * KV-ключи:
 *  ['fr', uid]  → FrState (друзья, заявки, инвайты, непрочитанные,
 *                 короткий код для добавления)
 *  ['fc', code] → uid (обратный индекс короткого кода)
 *  ['chat', a, b] → история сообщений пары (uids по возрастанию,
 *                 максимум CHAT_MSGS_MAX записей)
 *  ['on', uid]  → timestamp последнего присутствия (для «онлайн»)
 */

interface FrFriend {
  uid: string;
  name: string;
  at: number;
}
interface FrReq {
  uid: string;
  name: string;
  at: number;
}
interface FrInvite {
  from: string;
  fromName: string;
  code: string;
  at: number;
}
interface FrState {
  code: string;
  friends: FrFriend[];
  reqs: FrReq[];
  sent: { uid: string; at: number }[];
  invites: FrInvite[];
  unread: Record<string, number>;
}
interface ChatMsg {
  from: string;
  name: string;
  text: string;
  at: number;
}

function newFrCode(): string {
  return Array.from(
    { length: FC_LEN },
    () => FC_CHARS[Math.floor(Math.random() * FC_CHARS.length)],
  ).join('');
}

/** состояние игрока (создаётся при первом касании): короткий код
 *  регистрируется в ['fc', code] → uid */
async function getFr(uid: string): Promise<FrState | null> {
  if (!uid || uid === 'anon') return null;
  const e = await kv.get<FrState>(['fr', uid]);
  if (e?.value) return e.value;
  // создать: короткий код без коллизий. Task 45: ОДНА проверка
  // (пространство 31^6 ≈ 900 млн — повторы практически
  // невозможны; раньше до 4-x get'ов на каждого нового игрока)
  for (let i = 0; i < 2; i++) {
    const code = newFrCode();
    const taken = await kv.get(['fc', code]);
    if (taken?.value) continue;
    const st: FrState = {
      code,
      friends: [],
      reqs: [],
      sent: [],
      invites: [],
      unread: {},
    };
    await kv.set(['fr', uid], st);
    await kv.set(['fc', code], uid);
    return st;
  }
  return null;
}

async function putFr(uid: string, st: FrState): Promise<void> {
  await kv.set(['fr', uid], st);
}

/** онлайн ли uid (по маркеру присутствия) */
async function isOnlineUid(uid: string): Promise<boolean> {
  // свой изолят знает лучше: есть живой локальный сокет с этим uid
  for (const s of sockets) {
    if (s.uid === uid) return true;
  }
  const e = await kv.get<number>(['on', uid]);
  return !!e?.value && now() - e.value < FRIEND_ONLINE_MS;
}

/** вычислить «онлайн» для списка друзей за один проход */
async function onlineMap(uids: string[]): Promise<Record<string, boolean>> {
  const out: Record<string, boolean> = {};
  await Promise.all(
    uids.map(async (u) => {
      out[u] = await isOnlineUid(u);
    }),
  );
  return out;
}

/** публичное состояние друзей для клиента */
async function frView(uid: string): Promise<Record<string, unknown> | null> {
  const st = await getFr(uid);
  if (!st) return null;
  const t = now();
  const on = await onlineMap(st.friends.map((f) => f.uid));
  return {
    code: st.code,
    friends: st.friends.map((f) => ({
      uid: f.uid,
      name: f.name,
      online: on[f.uid] ?? false,
    })),
    reqs: st.reqs.map((r) => ({ uid: r.uid, name: r.name, at: r.at })),
    sent: st.sent.map((s) => s.uid),
    invites: st.invites
      .filter((i) => t - i.at < INVITE_TTL_MS)
      .map((i) => ({
        from: i.from,
        fromName: i.fromName,
        code: i.code,
        at: i.at,
      })),
    unread: st.unread,
  };
}

/** разослать состояние друзьям всем локальным сокетам uid */
async function pushFr(uid: string): Promise<void> {
  const v = await frView(uid);
  if (!v) return;
  for (const s of sockets) {
    if (s.uid === uid) send(s, { t: 'friends', state: v });
  }
}

/** событие друзьям (жилое уведомление) всем локальным сокетам uid */
function frEvent(uid: string, ev: Record<string, unknown>): void {
  for (const s of sockets) {
    if (s.uid === uid) send(s, { t: 'f_event', ...ev });
  }
}

/** чат пары: ключ из uid'ов ПО ВОЗРАСТАНИЮ — оба пишут в один список */
function chatKey(a: string, b: string): KvKey {
  const [x, y] = [a, b].sort();
  return ['chat', x, y];
}

async function getChat(a: string, b: string): Promise<ChatMsg[]> {
  const e = await kv.get<ChatMsg[]>(chatKey(a, b));
  return Array.isArray(e?.value) ? e.value : [];
}

async function appendChat(
  from: string,
  fromName: string,
  to: string,
  text: string,
): Promise<ChatMsg> {
  const msgs = await getChat(from, to);
  const msg: ChatMsg = { from, name: fromName, text, at: now() };
  msgs.push(msg);
  await kv.set(chatKey(from, to), msgs.slice(-CHAT_MSGS_MAX));
  return msg;
}

/** присутствие: маркер в KV — не чаще ONLINE_TOUCH_MS */
function touchOnline(s: Sock): void {
  if (!s.uid || s.uid === 'anon') return;
  const t = now();
  if (t - s.lastOnlineTouch < ONLINE_TOUCH_MS) return;
  s.lastOnlineTouch = t;
  kv.set(['on', s.uid], t).catch(() => {});
}

/** разобрать « кому»: uid или короткий код → uid (или null) */
async function resolveTarget(
  m: Record<string, unknown>,
): Promise<string | null> {
  const to = typeof m.to === 'string' ? m.to.trim() : '';
  const code = typeof m.code === 'string' ? m.code.trim().toUpperCase() : '';
  if (to) return to;
  if (code) {
    const e = await kv.get<string>(['fc', code]);
    return e?.value ?? null;
  }
  return null;
}

function sanitizeText(raw: unknown): string {
  const s = typeof raw === 'string' ? raw.trim().replace(/\s+/g, ' ') : '';
  return [...s].slice(0, CHAT_TEXT_MAX).join('');
}

/** заявка в друзья: my → target. Встречные заявки — сразу дружба. */
async function frAdd(
  s: Sock,
  m: Record<string, unknown>,
): Promise<void> {
  const target = await resolveTarget(m);
  if (!target || target === s.uid) {
    errOf(s, m, 'BAD_TARGET');
    return;
  }
  const [mine, theirs] = await Promise.all([
    getFr(s.uid),
    getFr(target),
  ]);
  if (!mine || !theirs) {
    errOf(s, m, 'BAD_TARGET');
    return;
  }
  if (mine.friends.some((f) => f.uid === target)) {
    errOf(s, m, 'ALREADY_FRIENDS');
    return;
  }
  // ВСТРЕЧНАЯ заявка: target уже просился ко мне — сразу дружим
  const mutual = mine.reqs.some((r) => r.uid === target);
  if (mutual) {
    await frAccept(s, { ...m, from: target });
    return;
  }
  // уже отправляли — тихо обновляем имя и время
  if (!mine.sent.some((x) => x.uid === target)) {
    if (mine.sent.length >= FRIEND_REQS_MAX) mine.sent.shift();
    mine.sent.push({ uid: target, at: now() });
  }
  if (!theirs.reqs.some((r) => r.uid === s.uid)) {
    if (theirs.reqs.length >= FRIEND_REQS_MAX) theirs.reqs.shift();
    theirs.reqs.push({ uid: s.uid, name: s.name, at: now() });
  }
  await putFr(s.uid, mine);
  await putFr(target, theirs);
  const resp = await frView(s.uid);
  if (resp) send(s, { t: 'friends', state: resp, rid: m.rid });
  frEvent(target, { kind: 'req', uid: s.uid, name: s.name });
  await pushFr(target);
}

/** принять заявку: с обеих сторон — друзья */
async function frAccept(
  s: Sock,
  m: Record<string, unknown>,
): Promise<void> {
  const from = typeof m.from === 'string' ? m.from.trim() : '';
  const mine = await getFr(s.uid);
  const theirs = await getFr(from);
  if (!mine || !theirs) {
    errOf(s, m, 'BAD_TARGET');
    return;
  }
  const req = mine.reqs.find((r) => r.uid === from);
  if (!req) {
    errOf(s, m, 'NO_REQ');
    return;
  }
  mine.reqs = mine.reqs.filter((r) => r.uid !== from);
  mine.sent = mine.sent.filter((x) => x.uid !== from);
  if (!mine.friends.some((f) => f.uid === from)) {
    if (mine.friends.length >= FRIENDS_MAX) mine.friends.shift();
    mine.friends.push({ uid: from, name: req.name, at: now() });
  }
  theirs.reqs = theirs.reqs.filter((r) => r.uid !== s.uid);
  theirs.sent = theirs.sent.filter((x) => x.uid !== s.uid);
  if (!theirs.friends.some((f) => f.uid === s.uid)) {
    if (theirs.friends.length >= FRIENDS_MAX) theirs.friends.shift();
    theirs.friends.push({ uid: s.uid, name: s.name, at: now() });
  }
  await putFr(s.uid, mine);
  await putFr(from, theirs);
  const resp = await frView(s.uid);
  if (resp) send(s, { t: 'friends', state: resp, rid: m.rid });
  frEvent(from, { kind: 'accept', uid: s.uid, name: s.name });
  await pushFr(from);
}

/* ==================== МАТЧМЕЙКИНГ ==================== */

/** подпишись на свой тикет: когда другой изолят его «подберёт» —
 *  пришлём сокету готовую комнату */
function ensureTicketWatch(sock: Sock, ticketId: string): void {
  if (ticketWatches.has(ticketId)) return;
  try {
    const reader = kv.watch([['mm', ticketId]]).getReader();
    ticketWatches.set(ticketId, reader);
    const pump = async () => {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) return;
        const tk = value?.[0]?.value as TicketState | null;
        if (!tk || !tk.paired || !sock.alive) continue;
        // подобрали! втаскиваем сокет в комнату
        sock.mmTicket = null;
        releaseTicketWatch(ticketId);
        const room = await getFreshRoom(tk.paired.code);
        if (!room) continue;
        sock.roomCode = room.code;
        sock.playerId = tk.paired.playerId;
        ensureRoomWatch(room.code);
        send(sock, { t: 'room', view: view(room), playerId: tk.paired.playerId });
        return;
      }
    };
    void pump();
  } catch {
    // без watch — клиент узнает по match-heart ответу
  }
}

function releaseTicketWatch(ticketId: string): void {
  const r = ticketWatches.get(ticketId);
  if (!r) return;
  ticketWatches.delete(ticketId);
  try {
    r.cancel();
  } catch {
    // ignore
  }
}

async function dropTicket(sock: Sock): Promise<void> {
  const id = sock.mmTicket;
  sock.mmTicket = null;
  if (id) {
    releaseTicketWatch(id);
    await kv.delete(['mm', id]).catch(() => {});
  }
}

/** обновить lastSeen тикета (сокет жив — тикет жив) */
async function touchTicket(sock: Sock): Promise<void> {
  if (!sock.mmTicket) return;
  const e = await kv.get<TicketState>(['mm', sock.mmTicket]);
  if (!e?.value) {
    // тикет протух и вычищен — пересоздадим из сокета
    await createTicketFor(sock);
    return;
  }
  await kv.atomic()
    .check(e as KvEntry<unknown>)
    .set(['mm', sock.mmTicket], { ...e.value, lastSeen: now() })
    .commit()
    .catch(() => {});
}

async function createTicketFor(
  sock: Sock,
  level = 1,
): Promise<void> {
  const id = rndId();
  const tk: TicketState = {
    id,
    name: sock.name || 'Игрок',
    hue: rndHue(),
    level,
    createdAt: now(),
    lastSeen: now(),
    uid: sock.uid,
    paired: null,
  };
  await kv.set(['mm', id], tk);
  sock.mmTicket = id;
  ensureTicketWatch(sock, id);
}

/** попробовать подобрать пары и подсадить одиночек в открытые игры */
async function tryMatchAll(): Promise<void> {
  const t = now();
  const fresh: TicketState[] = [];
  try {
    for await (const e of kv.list<TicketState>({ prefix: ['mm'] })) {
      const tk = e.value;
      if (!tk || tk.paired) continue;
      const age = t - tk.lastSeen;
      if (age > TICKET_TTL_MS) {
        await kv.delete(e.key);
        continue;
      }
      // протухший для спаривания призрак: сердце живого клиента —
      // каждые ~4 c; старше 8 c без сердца — сокет мёртв
      if (age > TICKET_PAIR_FRESH_MS) continue;
      fresh.push(tk);
    }
  } catch {
    return;
  }
  fresh.sort((a, b) => a.createdAt - b.createdAt);
  // пары из очереди
  for (let i = 0; i + 1 < fresh.length; i += 2) {
    const ok = await pairTickets(fresh[i], fresh[i + 1]);
    if (ok) {
      fresh.splice(i, 2);
      i -= 2;
    }
  }
  // одиночка — в первую открытую комнату
  if (fresh.length > 0) await joinFirstOpenRoom(fresh[0]);
}

async function pairTickets(a: TicketState, b: TicketState): Promise<boolean> {
  const code = newCode();
  // УРОВЕНЬ МАТЧА (Фидбек Task 39): стартуем от МЕНЬШЕГО уровня
  // игроков — слабому не дают боев не по зубам, сильному не скучно
  const level = clamp(Math.min(a.level, b.level), 1, 999);
  const room: RoomState = {
    code,
    level,
    seed: newSeed(),
    status: 'playing',
    hostId: rndId(),
    visibility: 'closed',
    startedAt: now() + INTRO_BUDGET_MS,
    timeTotalMs: timeForLevel(level),
    createdAt: now(),
    players: [],
    result: null,
    advanceBy: {},
    lastEvent: null,
  };
  const hostId = room.hostId;
  const guestId = rndId();
  room.players = [
    {
      id: hostId,
      name: a.name,
      hue: a.hue,
      score: 0,
      pairsDone: 0,
      lastSeen: now(),
      finished: null,
      wins: 0,
      uid: a.uid,
    },
    {
      id: guestId,
      name: b.name,
      hue: b.hue,
      score: 0,
      pairsDone: 0,
      lastSeen: now(),
      finished: null,
      wins: 0,
      uid: b.uid,
    },
  ];
  const ea = await kv.get<TicketState>(['mm', a.id]);
  const eb = await kv.get<TicketState>(['mm', b.id]);
  if (!ea?.value || !eb?.value || ea.value.paired || eb.value.paired) {
    return false;
  }
  const res = await kv.atomic()
    .check(ea as KvEntry<unknown>)
    .check(eb as KvEntry<unknown>)
    .set(['mm', a.id], { ...ea.value, paired: { code, playerId: hostId } })
    .set(['mm', b.id], { ...eb.value, paired: { code, playerId: guestId } })
    .set(['room', code], room)
    .commit();
  return res.ok;
}

async function joinFirstOpenRoom(tk: TicketState): Promise<boolean> {
  const t = now();
  let target: { code: string; at: number } | null = null;
  try {
    // SQL-проекция ждущих комнат (Task 45): без полного JSON-скана
    if (kv instanceof SqlKv && typeof kv.lobbyWaiting === 'function') {
      const rows = await kv.lobbyWaiting();
      const cands = rows
        .filter((r) => r.players < 2 && t - r.hostLastSeen <= WAITING_HOST_STALE_MS)
        .map((r) => ({ code: r.code, at: r.createdAt }));
      cands.sort((x, y) => x.at - y.at);
      target = cands[0] ?? null;
    } else {
      const cands: { code: string; at: number }[] = [];
      for await (const e of kv.list<RoomState>({ prefix: ['room'] })) {
        const r = e.value;
        if (!r || r.status !== 'waiting' || r.visibility !== 'open') continue;
        if (r.players.length >= 2) continue;
        const host = r.players[0];
        if (!host || t - host.lastSeen > WAITING_HOST_STALE_MS) continue;
        cands.push({ code: r.code, at: r.createdAt });
      }
      cands.sort((x, y) => x.at - y.at);
      target = cands[0] ?? null;
    }
  } catch {
    return false;
  }
  if (!target) return false;
  const guestId = rndId();
  // входящий в открытую игру — тоже от меньшего уровня (Task 39)
  const res = await mutateRoom(target.code, (r) => {
    if (r.status !== 'waiting' || r.players.length >= 2) return 'abort';
    r.level = clamp(Math.min(r.level, tk.level), 1, 999);
    r.timeTotalMs = timeForLevel(r.level);
    r.players.push({
      id: guestId,
      name: tk.name,
      hue: tk.hue,
      score: 0,
      pairsDone: 0,
      lastSeen: now(),
      finished: null,
      wins: 0,
      uid: tk.uid,
    });
    r.status = 'playing';
    r.startedAt = now() + INTRO_BUDGET_MS;
    return r;
  });
  if (!res.ok || !res.room) return false;
  const et = await kv.get<TicketState>(['mm', tk.id]);
  if (!et?.value || et.value.paired) return false;
  await kv.atomic()
    .check(et as KvEntry<unknown>)
    .set(['mm', tk.id], { ...et.value, paired: { code: target.code, playerId: guestId } })
    .commit();
  return true;
}

/* ==================== ОБРАБОТКА СООБЩЕНИЙ ==================== */

function errOf(s: Sock, m: Record<string, unknown>, code: string): void {
  send(s, { t: 'err', code, rid: m.rid });
}

async function onMessage(s: Sock, raw: string): Promise<void> {
  let m: Record<string, unknown>;
  try {
    m = JSON.parse(raw);
    if (!m || typeof m !== 'object') return;
  } catch {
    return;
  }
  // присутствие для друзей: любой обмен — «я онлайн» (с троттлингом)
  touchOnline(s);
  const t = typeof m.t === 'string' ? m.t : '';
  switch (t) {
    /* ---------- представиться/вернуться в комнату ---------- */
    case 'hello': {
      if (typeof m.uid === 'string' && m.uid.length > 0) s.uid = m.uid;
      if (typeof m.name === 'string' && m.name.trim()) {
        s.name = sanitizeName(m.name);
      }
      send(s, { t: 'hello', ok: true, uid: s.uid });
      // друзья: состояние при каждом приветствии (заявки/чат/инвайты).
      // Task 45: ОДИН проход — раньше getFr + pushFr читали состояние
      // ДВАЖДЫ (двойные RTT при каждом реконнекте).
      // БЕЗ СОЗДАНИЯ: у нового игрока состояния ещё нет — создавать
      // его дорого (4 запроса) и незачем, панель друзей откроется —
      // f_sync создаст. Так hello нового игрока = 1 чтение вместо 5-6.
      if (s.uid !== 'anon') {
        const e = await kv.get<FrState>(['fr', s.uid]).catch(() => null);
        if (e?.value) {
          const v = await frView(s.uid).catch(() => null);
          if (v) {
            for (const sock of sockets) {
              if (sock.uid === s.uid) send(sock, { t: 'friends', state: v });
            }
          }
        }
      }
      const code = normalizeCode(m.code);
      const pid = typeof m.playerId === 'string' ? m.playerId : null;
      if (code && pid) {
        // заявляем права на смену привязки: если за время чтения KV
        // сокет успел создать/войти в другую комнату — не трогаем её
        const myEpoch = ++s.bindEpoch;
        // комната жива? да — привязываемся и шлём вьюху;
        // НЕТ — молчим: никаких страшных ошибок при приветствии
        const room = await getFreshRoom(code);
        if (s.bindEpoch !== myEpoch) return; // нас обогнали
        if (room && room.players.some((p) => p.id === pid)) {
          bindSock(s, room.code, pid);
          ensureRoomWatch(room.code);
          // прогреваем присутствие — перезагрузка не должна рвать матч.
          // Task 45: ОДИН атомарный UPDATE вместо CAS-транзакции
          try {
            if (kv instanceof SqlKv && typeof kv.touchPlayerSeen === 'function') {
              await kv.touchPlayerSeen(room.code, pid);
            } else {
              await mutateRoom(room.code, (r) => {
                const p = r.players.find((x) => x.id === pid);
                if (p) p.lastSeen = now();
                return autoRules(r, now()) ?? 'abort';
              });
            }
          } catch {
            // прогрев не критичен — hb подхватит
          }
          send(s, { t: 'room', view: view(room) });
        } else {
          bindSock(s, null, null);
        }
      }
      return;
    }

    /* ---------- лобби открытых игр ---------- */
    case 'lobby': {
      s.lobby = m.on === true;
      if (s.lobby) {
        const [rooms, searching] = await Promise.all([
          listOpenRooms(),
          listSearching(),
        ]);
        send(s, { t: 'lobby', rooms, searching, rid: m.rid });
      }
      ensureLobbyLoop();
      return;
    }

    /* ---------- создать игру ---------- */
    case 'create': {
      await dropTicket(s);
      const name = sanitizeName(m.name);
      const level = clamp(Math.floor(Number(m.level) || 1), 1, 999);
      const visibility = m.visibility === 'open' ? 'open' : 'closed';
      let code = '';
      for (let i = 0; i < 5; i++) {
        code = newCode();
        const taken = await kv.get(['room', code]);
        if (!taken?.value) break;
        code = '';
      }
      if (!code) {
        errOf(s, m, 'NETWORK');
        return;
      }
      const hostId = rndId();
      const room: RoomState = {
        code,
        level,
        seed: newSeed(),
        status: 'waiting',
        hostId,
        visibility,
        startedAt: 0,
        timeTotalMs: timeForLevel(level),
        createdAt: now(),
        players: [
          {
            id: hostId,
            name,
            hue: rndHue(),
            score: 0,
            pairsDone: 0,
            lastSeen: now(),
            finished: null,
            wins: 0,
            uid: s.uid,
          },
        ],
        result: null,
        advanceBy: {},
        lastEvent: null,
      };
      const res = await kv.atomic()
        .check({
          key: ['room', code],
          value: null,
          versionstamp: null as unknown as string,
        })
        .set(['room', code], room)
        .commit();
      if (!res.ok) {
        errOf(s, m, 'NETWORK');
        return;
      }
      s.name = name;
      bindSock(s, code, hostId);
      ensureRoomWatch(code);
      console.log(`[room] create ${code} · «${name}» · ур.${level}`);
      send(s, { t: 'room', view: view(room), playerId: hostId, rid: m.rid });
      return;
    }

    /* ---------- вход по коду (с ретраями свежей комнаты) ---------- */
    case 'join': {
      await dropTicket(s);
      const code = normalizeCode(m.code);
      if (!code) {
        errOf(s, m, 'BAD_CODE');
        return;
      }
      const name = sanitizeName(m.name);
      // уровень входящего: комната стартует от МЕНЬШЕГО (Task 39)
      const joinerLevel = clamp(
        Math.floor(Number(m.level) || 0) || 999,
        1,
        999,
      );
      const joinerId = rndId();
      const joiner = () => ({
        id: joinerId,
        name,
        hue: rndHue(),
        score: 0,
        pairsDone: 0,
        lastSeen: now(),
        finished: null,
        wins: 0,
        uid: s.uid,
      });
      const res = await mutateRoom(code, (r) => {
        if (r.status !== 'waiting' || r.players.length >= 2) return 'abort';
        if (joinerLevel < r.level) {
          r.level = joinerLevel;
          r.timeTotalMs = timeForLevel(r.level);
        }
        r.players.push(joiner());
        r.status = 'playing';
        r.startedAt = now() + INTRO_BUDGET_MS;
        return r;
      });
      // «abort» = не вошли (занято/идёт игра); успешный вход виден по игроку
      if (!res.ok || !res.room || !res.room.players.some((p) => p.id === joinerId)) {
        // мог не найтись из-за репликации KV — ретраи
        const fresh = await getFreshRoom(code);
        if (!fresh) {
          errOf(s, m, 'ROOM_NOT_FOUND');
          return;
        }
        if (fresh.status !== 'waiting' || fresh.players.length >= 2) {
          errOf(s, m, 'ROOM_FULL');
          return;
        }
        // редкий случай: комната «проявилась» между попытками — ещё раз
        const retry = await mutateRoom(code, (r) => {
          if (r.status !== 'waiting' || r.players.length >= 2) return 'abort';
          if (joinerLevel < r.level) {
            r.level = joinerLevel;
            r.timeTotalMs = timeForLevel(r.level);
          }
          r.players.push(joiner());
          r.status = 'playing';
          r.startedAt = now() + INTRO_BUDGET_MS;
          return r;
        });
        if (
          !retry.ok || !retry.room ||
          !retry.room.players.some((p) => p.id === joinerId)
        ) {
          errOf(s, m, 'ROOM_FULL');
          return;
        }
        res.room = retry.room;
        res.ok = true;
      }
      const room = res.room!;
      s.name = name;
      bindSock(s, room.code, joinerId);
      ensureRoomWatch(room.code);
      // обоим локальным: вьюха старта (соперник узнает и через watch)
      pushLocal(room.code, room);
      console.log(`[room] join ${room.code} · «${name}» · ур.${room.level}`);
      send(s, { t: 'room', view: view(room), playerId: joinerId, rid: m.rid });
      return;
    }

    /* ---------- прогресс + присутствие ---------- */
    case 'view': {
      const code = s.roomCode;
      if (!code || !s.playerId) {
        errOf(s, m, 'ROOM_NOT_FOUND');
        return;
      }
      // ЧИСТОЕ ЧТЕНИЕ (Task 45). Раньше каждый опрос (2 игрока ×
      // каждые 4 c + лобби каждые 3 c) шёл полной CAS-записью
      // (SELECT FOR UPDATE + UPDATE ≈ 700 мс блокировки строки при
      // RTT 225 мс) — строка комнаты была под замком почти всё
      // время, очередь на пуле росла безгранично, join/view/health
      // отвечали 10+ c → «вылетает во время игры по сети».
      // Присутствие и очки пишут ДЕШЁВЫЕ пути: 'ping' (троттлинг
      // 6 c) и 'event' (момент сбора пары); авт-исходы досматривает
      // свипер каждые 2.5 c. Здесь — только читаем и отвечаем.
      const room = await getRoom(code);
      if (!room) {
        errOf(s, m, 'ROOM_NOT_FOUND');
        return;
      }
      send(s, { t: 'room', view: view(room), rid: m.rid });
      return;
    }

    /* ---------- собрал пару: релея сопернику ---------- */
    case 'event': {
      if (m.kind !== 'match') return;
      const code = s.roomCode;
      const myPid = s.playerId;
      if (!code || !myPid) return;
      const score = Number(m.score);
      const pairs = Number(m.pairsDone);
      // Task 45: ГОРЯЧИЙ ПУТЬ — один атомарный JSONB-UPDATE
      // (было: полная CAS-транзакция ≈ 1.1 c — очередь душа пул,
      // событие пар висело секунды = «соперник не видит мой ход»)
      const ev = {
        playerId: myPid,
        tile1Id: clamp(Math.floor(Number(m.tile1Id) || 0), 0, 999),
        tile2Id: clamp(Math.floor(Number(m.tile2Id) || 0), 0, 999),
        score: Number.isFinite(score) ? Math.round(score) : 0,
        pairsDone: Number.isFinite(pairs) ? Math.floor(pairs) : 0,
        at: now(),
      };
      try {
        if (kv instanceof SqlKv && typeof kv.applyMatchEvent === 'function') {
          const ok = await kv.applyMatchEvent(
            code,
            myPid,
            Number.isFinite(score) ? score : 0,
            Number.isFinite(pairs) ? pairs : 0,
            ev,
          );
          if (!ok) return;
          const room = await getRoom(code);
          if (room) pushLocal(code, room); // локальному сопернику сразу
          return;
        }
      } catch {
        // база моргнула — фолбэк на CAS-путь ниже
      }
      const res = await mutateRoom(code, (r) => {
        const p = r.players.find((x) => x.id === myPid);
        if (!p) return r;
        p.lastSeen = now();
        if (r.status === 'playing') {
          if (Number.isFinite(score)) p.score = clamp(score, 0, 10_000_000);
          if (Number.isFinite(pairs)) {
            p.pairsDone = clamp(Math.floor(pairs), 0, 1000);
          }
          r.lastEvent = ev;
        }
        return r;
      });
      if (res.room) pushLocal(code, res.room); // локальному сопернику сразу
      return; // соперник на другом изоляте получит через watch
    }

    /* ---------- терминальное событие ---------- */
    case 'finish': {
      const code = s.roomCode;
      if (!code || !s.playerId) {
        errOf(s, m, 'ROOM_NOT_FOUND');
        return;
      }
      const why: 'cleared' | 'tray' = m.reason === 'cleared' ? 'cleared' : 'tray';
      const score = Number(m.score);
      const pairs = Number(m.pairsDone);
      const res = await mutateRoom(code, (r) => {
        const p = r.players.find((x) => x.id === s.playerId);
        if (!p) return r;
        p.lastSeen = now();
        p.finished = why;
        if (Number.isFinite(score)) p.score = clamp(score, 0, 10_000_000);
        if (Number.isFinite(pairs)) {
          p.pairsDone = clamp(Math.floor(pairs), 0, 1000);
        }
        if (r.status === 'playing') {
          if (why === 'cleared') {
            return finishRoom(r, p.id, 'cleared', now());
          }
          const other = r.players.find((x) => x.id !== p.id);
          if (other) return finishRoom(r, other.id, 'tray', now());
        }
        return r;
      });
      if (!res.ok && res.room === null) {
        errOf(s, m, 'ROOM_NOT_FOUND');
        return;
      }
      if (res.room) {
        pushLocal(code, res.room);
        send(s, { t: 'room', view: view(res.room), rid: m.rid });
      }
      return;
    }

    /* ---------- реванш / следующий уровень (оба согласны) ---------- */
    case 'advance': {
      const code = s.roomCode;
      if (!code || !s.playerId) {
        errOf(s, m, 'ROOM_NOT_FOUND');
        return;
      }
      const kind: 'rematch' | 'next' = m.kind === 'next' ? 'next' : 'rematch';
      const advPid = s.playerId;
      const res = await mutateRoom(code, (r) => {
        if (r.status !== 'result') return 'abort';
        if (r.players.length < 2) return 'abort';
        const p = r.players.find((x) => x.id === advPid);
        if (p) {
          p.lastSeen = now();
          r.advanceBy[advPid] = kind;
        }
        const [a, b] = r.players;
        const ka = a ? r.advanceBy[a.id] : undefined;
        const kb = b ? r.advanceBy[b.id] : undefined;
        if (!(ka && kb && ka === kb)) {
          // голос СОХРАНЯЕМ: второй игрок увидит предложение
          return r;
        }
        // оба согласны — старт нового матча (счёт серии НЕ сбрасываем).
        // «Дальше» поднимает уровень сразу на 2 (Фидбек Task 39:
        // не топчемся на одном, прогресс заметнее)
        r.advanceBy = {};
        if (kind === 'next') r.level = clamp(r.level + 2, 1, 999);
        r.seed = newSeed();
        r.result = null;
        r.lastEvent = null;
        r.startedAt = now() + INTRO_BUDGET_MS;
        r.timeTotalMs = timeForLevel(r.level);
        for (const p2 of r.players) {
          p2.score = 0;
          p2.pairsDone = 0;
          p2.finished = null;
          p2.lastSeen = now();
        }
        r.status = 'playing';
        return r;
      });
      if (!res.room) {
        // комнаты действительно нет (CAS-конфликт теперь возвращает
        // живую комнату, а не ложное «пусто» — согласие на реванш
        // больше не ломается спорадической ROOM_EMPTY)
        errOf(s, m, 'ROOM_EMPTY');
        return;
      }
      // старт нового матча — заметно в логах Deploy (Task 45)
      if (res.changed && res.room.status === 'playing') {
        console.log(
          `[room] advance ${code} · ${kind} · старт ур.${res.room.level}`,
        );
      } else {
        console.log(
          `[room] advance ${code} · ${kind} · голос записан, ждём второго`,
        );
      }
      pushLocal(code, res.room);
      send(s, { t: 'room', view: view(res.room), rid: m.rid });
      return;
    }

    /* ---------- выйти (сопернику — победа) ---------- */
    case 'leave': {
      const code = s.roomCode;
      const pid = s.playerId;
      bindSock(s, null, null);
      if (!code || !pid) {
        send(s, { t: 'ok', rid: m.rid });
        return;
      }
      const res = await mutateRoom(code, (r) => {
        r.players = r.players.filter((x) => x.id !== pid);
        delete r.advanceBy[pid];
        if (r.players.length === 0) return 'delete'; // комнату удалим в mutateRoom
        if (r.status === 'playing') {
          return finishRoom(r, r.players[0].id, 'left', now());
        }
        return r;
      });
      if (res.room) pushLocal(code, res.room);
      send(s, { t: 'ok', rid: m.rid });
      return;
    }

    /* ---------- быстрый матч ---------- */
    case 'match': {
      if (typeof m.name === 'string' && m.name.trim()) {
        s.name = sanitizeName(m.name);
      }
      const level = clamp(Math.floor(Number(m.level) || 1), 1, 999);
      if (!s.mmTicket) await createTicketFor(s);
      if (s.mmTicket) {
        const e = await kv.get<TicketState>(['mm', s.mmTicket]);
        if (e?.value && !e.value.paired) {
          await kv.atomic()
            .check(e as KvEntry<unknown>)
            .set(['mm', s.mmTicket], {
              ...e.value,
              name: s.name || 'Игрок',
              level,
              lastSeen: now(),
            })
            .commit()
            .catch(() => {});
        }
      }
      await tryMatchAll();
      // сразу могли подобрать: watch мог уже втащить нас в комнату
      // (и обнулить mmTicket) — проверяем и то, и другое
      const myTicket = s.mmTicket;
      if (myTicket) {
        const e = await kv.get<TicketState>(['mm', myTicket]);
        if (e?.value?.paired) {
          await enterPairedRoom(s, e.value.paired.code, e.value.paired.playerId);
          const room = await getRoom(e.value.paired.code);
          if (room) {
            send(s, {
              t: 'room',
              view: view(room),
              playerId: e.value.paired.playerId,
              rid: m.rid,
            });
            return;
          }
        }
      } else if (s.roomCode && s.playerId) {
        // watch уже втащил — отвечаем готовой комнатой
        const room = await getRoom(s.roomCode);
        if (room) {
          send(s, { t: 'room', view: view(room), playerId: s.playerId, rid: m.rid });
          return;
        }
      }
      send(s, { t: 'mm', status: 'search', rid: m.rid });
      return;
    }

    /** держим тикет живым (клиент раз в ~4 c, пока ищет) */
    case 'match-heart': {
      if (!s.mmTicket) {
        if (s.roomCode && s.playerId) {
          // watch уже втащил в комнату — отдаём САМУ КОМНАТУ:
          // клиенту нужны креды и вьюха, иначе он зависнет в
          // радаре (Task 36: тап по «ищущему» из меню не подводил
          // самого ищущего)
          const room = await getRoom(s.roomCode);
          if (room) {
            send(s, {
              t: 'room',
              view: view(room),
              playerId: s.playerId,
              rid: m.rid,
            });
            return;
          }
          send(s, { t: 'mm', status: 'paired', rid: m.rid });
          return;
        }
        // САМОВОССТАНОВЛЕНИЕ ОЧЕРЕДИ (Фидбек «не соединяется при
        // быстрой игре»): сокет мог пережить обрыв/переподключение —
        // старый тикет при close уже удалён, и на новом сокете его
        // нет. Раньше клиент вечно висел в «поиске»: heart отвечал
        // «search», но тикета в очереди не было. Встаём заново.
        const lvl = Number(m.level);
        await createTicketFor(
          s,
          Number.isFinite(lvl) ? clamp(Math.floor(lvl), 1, 999) : 1,
        );
      }
      await touchTicket(s);
      await tryMatchAll();
      const ht = s.mmTicket;
      const e = ht ? await kv.get<TicketState>(['mm', ht]) : null;
      if (e?.value?.paired) {
        await enterPairedRoom(s, e.value.paired.code, e.value.paired.playerId);
        const room = await getRoom(e.value.paired.code);
        if (room) {
          send(s, {
            t: 'room',
            view: view(room),
            playerId: e.value.paired.playerId,
            rid: m.rid,
          });
        }
        return;
      }
      // watch мог уже втащить нас в комнату между tryMatchAll и
      // чтением тикета (memory-KV гонка: pump обнуляет mmTicket) —
      // отвечаем комнатой сокета, иначе клиент получит «search»
      // при живом матче и застрянет в радаре
      if (s.roomCode && s.playerId) {
        const room = await getRoom(s.roomCode);
        if (room) {
          send(s, { t: 'room', view: view(room), playerId: s.playerId, rid: m.rid });
          return;
        }
      }
      send(s, { t: 'mm', status: 'search', rid: m.rid });
      return;
    }

    case 'match-leave': {
      await dropTicket(s);
      send(s, { t: 'ok', rid: m.rid });
      return;
    }

    /* ---------- ДРУЗЬЯ (Task 37) ---------- */
    case 'f_sync': {
      const v = await frView(s.uid);
      if (v) send(s, { t: 'friends', state: v, rid: m.rid });
      else send(s, { t: 'ok', rid: m.rid });
      return;
    }
    case 'f_add': {
      await frAdd(s, m);
      return;
    }
    case 'f_accept': {
      await frAccept(s, m);
      return;
    }
    case 'f_decline': {
      const from = typeof m.from === 'string' ? m.from.trim() : '';
      const mine = await getFr(s.uid);
      if (mine) {
        mine.reqs = mine.reqs.filter((r) => r.uid !== from);
        await putFr(s.uid, mine);
        const resp = await frView(s.uid);
        if (resp) send(s, { t: 'friends', state: resp, rid: m.rid });
        // у отправителя заявки — убрать из sent
        const theirs = await getFr(from);
        if (theirs) {
          theirs.sent = theirs.sent.filter((x) => x.uid !== s.uid);
          await putFr(from, theirs);
          await pushFr(from);
        }
      }
      return;
    }
    case 'f_remove': {
      const uid = typeof m.uid === 'string' ? m.uid.trim() : '';
      const mine = await getFr(s.uid);
      const theirs = await getFr(uid);
      // СНАЧАЛА убираем переписку (до пушей — клиент не должен
      // успеть прочитать уже удалённую дружбу)
      await kv.delete(chatKey(s.uid, uid)).catch(() => {});
      if (mine) {
        mine.friends = mine.friends.filter((f) => f.uid !== uid);
        delete mine.unread[uid];
        await putFr(s.uid, mine);
        const resp = await frView(s.uid);
        if (resp) send(s, { t: 'friends', state: resp, rid: m.rid });
      }
      if (theirs) {
        theirs.friends = theirs.friends.filter((f) => f.uid !== s.uid);
        delete theirs.unread[s.uid];
        await putFr(uid, theirs);
        frEvent(uid, { kind: 'removed', uid: s.uid, name: s.name });
        await pushFr(uid);
      }
      return;
    }
    case 'f_msg': {
      const to = typeof m.to === 'string' ? m.to.trim() : '';
      const text = sanitizeText(m.text);
      if (!to || !text) {
        errOf(s, m, 'BAD_TARGET');
        return;
      }
      const mine = await getFr(s.uid);
      if (!mine || !mine.friends.some((f) => f.uid === to)) {
        errOf(s, m, 'NOT_FRIENDS');
        return;
      }
      const msg = await appendChat(s.uid, s.name, to, text);
      // непрочитанные — у получателя
      const theirs = await getFr(to);
      if (theirs) {
        theirs.unread[s.uid] = (theirs.unread[s.uid] ?? 0) + 1;
        await putFr(to, theirs);
      }
      send(s, { t: 'ok', rid: m.rid });
      frEvent(to, {
        kind: 'msg',
        uid: s.uid,
        name: s.name,
        text: msg.text,
        at: msg.at,
      });
      await pushFr(to);
      return;
    }
    case 'f_read': {
      const withUid = typeof m.with === 'string' ? m.with.trim() : '';
      const mine = await getFr(s.uid);
      if (mine && mine.unread[withUid]) {
        delete mine.unread[withUid];
        await putFr(s.uid, mine);
      }
      send(s, { t: 'ok', rid: m.rid });
      return;
    }
    case 'f_chat_load': {
      const withUid = typeof m.with === 'string' ? m.with.trim() : '';
      const msgs = await getChat(s.uid, withUid);
      send(s, { t: 'f_chat', with: withUid, msgs, rid: m.rid });
      return;
    }
    case 'f_invite': {
      // зову друга в битву: создаю закрытую комнату и жду в ней,
      // другу уходит приглашение с кодом комнаты
      const to = typeof m.to === 'string' ? m.to.trim() : '';
      const level = clamp(Math.floor(Number(m.level) || 1), 1, 999);
      const mine = await getFr(s.uid);
      if (!mine || !mine.friends.some((f) => f.uid === to)) {
        errOf(s, m, 'NOT_FRIENDS');
        return;
      }
      await dropTicket(s);
      let code = '';
      for (let i = 0; i < 5; i++) {
        code = newCode();
        const taken = await kv.get(['room', code]);
        if (!taken?.value) break;
        code = '';
      }
      if (!code) {
        errOf(s, m, 'NETWORK');
        return;
      }
      const hostId = rndId();
      const room: RoomState = {
        code,
        level,
        seed: newSeed(),
        status: 'waiting',
        hostId,
        visibility: 'closed',
        startedAt: 0,
        timeTotalMs: timeForLevel(level),
        createdAt: now(),
        players: [
          {
            id: hostId,
            name: s.name,
            hue: rndHue(),
            score: 0,
            pairsDone: 0,
            lastSeen: now(),
            finished: null,
            wins: 0,
            uid: s.uid,
          },
        ],
        result: null,
        advanceBy: {},
        lastEvent: null,
      };
      const res = await kv.atomic()
        .check({
          key: ['room', code],
          value: null,
          versionstamp: null as unknown as string,
        })
        .set(['room', code], room)
        .commit();
      if (!res.ok) {
        errOf(s, m, 'NETWORK');
        return;
      }
      bindSock(s, code, hostId);
      ensureRoomWatch(code);
      // приглашение другу (живёт INVITE_TTL_MS)
      const theirs = await getFr(to);
      if (theirs) {
        const tnow = now();
        theirs.invites = theirs.invites.filter(
          (i) => i.from !== s.uid && tnow - i.at < INVITE_TTL_MS,
        );
        if (theirs.invites.length >= 5) theirs.invites.shift();
        theirs.invites.push({
          from: s.uid,
          fromName: s.name,
          code,
          at: tnow,
        });
        await putFr(to, theirs);
        frEvent(to, {
          kind: 'invite',
          uid: s.uid,
          name: s.name,
          code,
        });
        await pushFr(to);
      }
      send(s, { t: 'room', view: view(room), playerId: hostId, rid: m.rid });
      return;
    }
    case 'f_invite_reply': {
      const from = typeof m.from === 'string' ? m.from.trim() : '';
      const accept = m.accept === true;
      const mine = await getFr(s.uid);
      if (!mine) {
        errOf(s, m, 'BAD_TARGET');
        return;
      }
      const inv = mine.invites.find((i) => i.from === from);
      mine.invites = mine.invites.filter(
        (i) => i.from !== from || now() - i.at >= INVITE_TTL_MS,
      );
      await putFr(s.uid, mine);
      if (!accept || !inv) {
        if (inv) {
          frEvent(from, { kind: 'invite_declined', uid: s.uid, name: s.name });
          await pushFr(from);
        }
        send(s, { t: 'friends', state: await frView(s.uid), rid: m.rid });
        return;
      }
      // СОГЛАСЕН: входим в комнату приглашавшего (как обычный join)
      await dropTicket(s);
      const code = inv.code;
      // уровень отвечающего: комната — от МЕНЬШЕГО (Task 39)
      const myLevel = clamp(
        Math.floor(Number(m.level) || 0) || 999,
        1,
        999,
      );
      const joinerId = rndId();
      const joiner = () => ({
        id: joinerId,
        name: s.name,
        hue: rndHue(),
        score: 0,
        pairsDone: 0,
        lastSeen: now(),
        finished: null,
        wins: 0,
        uid: s.uid,
      });
      const res = await mutateRoom(code, (r) => {
        if (r.status !== 'waiting' || r.players.length >= 2) return 'abort';
        if (myLevel < r.level) {
          r.level = myLevel;
          r.timeTotalMs = timeForLevel(r.level);
        }
        r.players.push(joiner());
        r.status = 'playing';
        r.startedAt = now() + INTRO_BUDGET_MS;
        return r;
      });
      if (!res.ok || !res.room || !res.room.players.some((p) => p.id === joinerId)) {
        errOf(s, m, 'ROOM_NOT_FOUND');
        return;
      }
      const room = res.room;
      bindSock(s, room.code, joinerId);
      ensureRoomWatch(room.code);
      pushLocal(room.code, room);
      send(s, { t: 'room', view: view(room), playerId: joinerId, rid: m.rid });
      return;
    }

    case 'ping': {
      // фоновая вкладка: таймеры зажаты браузером, но сокет жив и
      // отвечает на hb — считаем это присутствием (lastSeen).
      // Троттлинг 6 c (Task 45): присутствие живёт при ≤12 c; сам
      // тап — ОДИН атомарный UPDATE (jsonb_set), не CAS-транзакция
      const code = s.roomCode;
      const pid = s.playerId;
      if (code && pid) {
        try {
          if (kv instanceof SqlKv && typeof kv.touchPlayerSeen === 'function') {
            await kv.touchPlayerSeen(code, pid);
          } else {
            await mutateRoom(code, (r) => {
              const p = r.players.find((x) => x.id === pid);
              if (p && now() - p.lastSeen > 6000) {
                p.lastSeen = now();
                return r;
              }
              return 'abort';
            });
          }
        } catch {
          // база моргнула — присутствие подтянется следующим тиком
        }
      }
      send(s, { t: 'pong', rid: m.rid });
      return;
    }
    default:
      return;
  }
}

/** втянуть сокет в подобранную комнату матчмейкинга */
async function enterPairedRoom(
  s: Sock,
  code: string,
  playerId: string,
): Promise<void> {
  const room = await getFreshRoom(code);
  if (!room || !room.players.some((p) => p.id === playerId)) return;
  s.mmTicket = null;
  bindSock(s, room.code, playerId);
  ensureRoomWatch(room.code);
  // прогреваем lastSeen — игрок только пришёл (Task 45: один
  // атомарный UPDATE вместо CAS-транзакции)
  try {
    if (kv instanceof SqlKv && typeof kv.touchPlayerSeen === 'function') {
      await kv.touchPlayerSeen(room.code, playerId);
    } else {
      await mutateRoom(room.code, (r) => {
        const p = r.players.find((x) => x.id === playerId);
        if (p) p.lastSeen = now();
        return r;
      });
    }
  } catch {
    // прогрев не критичен
  }
}

/* ==================== HTTP / WS СЕРВЕР ==================== */

async function handle(req: Request): Promise<Response> {
  // WS принимаем на ЛЮБОМ пути — решает заголовок upgrade, а не pathname:
  // работают и корень (wss://host), и /ws, и любой другой путь.
  const upgrade = req.headers.get('upgrade')?.toLowerCase() ?? '';
  if (upgrade.includes('websocket')) {
    const { socket, response } = Deno.upgradeWebSocket(req);
    const sock: Sock = {
      ws: socket,
      uid: 'anon',
      name: 'Игрок',
      roomCode: null,
      playerId: null,
      bindEpoch: 0,
      lobby: false,
      mmTicket: null,
      lastOnlineTouch: 0,
      alive: true,
    };
    socket.onopen = () => {
      sockets.add(sock);
    };
    socket.onmessage = (ev) => {
      const t0 = Date.now();
      void onMessage(sock, String(ev.data))
        .then(() => {
          // Task 45 (диагностика «вылетает по сети»): любое сообщение,
          // обработанное дольше 1.5 c, видно в логах Deploy
          const ms = Date.now() - t0;
          if (ms > 1500) {
            let kind = '?';
            try {
              kind = String(JSON.parse(String(ev.data)).t ?? '?');
            } catch { /* ignore */ }
            console.warn(`[slow] ${kind} ${ms} мс`);
          }
        })
        .catch((err) => {
          console.warn('[ws] handler:', err instanceof Error ? err.message : err);
        });
    };
    socket.onclose = () => {
      sock.alive = false;
      sockets.delete(sock);
      void dropTicket(sock);
      if (sock.roomCode) {
        // даём клиенту шанс вернуться (grace 30 c на серверных таймерах);
        // здесь только убираем локальную подписку, если больше некому
        const others = localRoomSocks(sock.roomCode);
        if (others.length === 0) releaseRoomWatch(sock.roomCode);
      }
    };
    socket.onerror = () => {
      try {
        socket.close();
      } catch {
        // ignore
      }
    };
    return response;
  }

  const url = new URL(req.url);
  if (url.pathname === '/health') {
    // Task 45: БЕЗ скана комнат (list тянул весь JSON всех комнат —
    // каждый health-запрос занимал соединение на сотни мс)
    return Response.json({
      ok: true,
      isolate: ISOLATE,
      kv: kvMode,
      boot: kvBoot,
      persistent: kvMode !== 'memory',
      // человеческая расшифровка (Task 45): друзья и комнаты
      // переживают рестарты ТОЛЬКО при persistent=true
      storage: kvMode === 'memory'
        ? 'MEMORY: друзья и комнаты НЕ переживают рестарт изолята'
        : `PERSISTENT (${kvMode})`,
      sockets: sockets.size,
      v: 5,
    });
  }
  if (url.pathname === '/') {
    return Response.json({
      ok: true,
      multiplayer: 'deno',
      ws: `${url.protocol === 'https:' ? 'wss' : 'ws'}://${url.host}/ws`,
      v: 5,
    });
  }
  return new Response('Not Found', { status: 404 });
}

/* фоновые циклы изолята (Task 45: реже — беречь лимит соединений
 *  filess.io и RTT 225 мс: вьюхи ≤ 2 c (watch), авт-исходы ≤ 5 c
 *  (тайминги дисконнекта 30 c / тайм-аута терпят запас 5 c) */
setInterval(() => void sweep().catch(() => {}), 5000);
// janitor: частый заход — только при живых сокетах; редкий фоновый —
// раз в 30 минут всем изолятам (пустые тоже чистят забытые комнаты)
const janitorDelay = 60_000 + Math.floor(Math.random() * 240_000);
setInterval(
  () => {
    if (sockets.size > 0) void janitor().catch(() => {});
  },
  300_000 + janitorDelay % 60_000,
);
setInterval(() => void janitor().catch(() => {}), 2 * 60 * 60_000);
setTimeout(() => void janitor().catch(() => {}), janitorDelay);

// hb: живость соединений (браузерные WS сами не пингуют).
// Каждые 5 c: держит NAT/прокси тёплым, клиент отвечает {t:'ping'}
// → сервер обновляет lastSeen (Task 45: реже — беречь пул SQL).
setInterval(() => {
  for (const s of sockets) send(s, { t: 'hb' });
}, 5_000);

Deno.serve({ port: PORT }, handle);
console.log(
  `[mj-server] изолят ${ISOLATE} слушает :${PORT} мгновенно · kv=${kvMode}(фон: подключается) · v5`,
);
